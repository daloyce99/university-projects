#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <arpa/inet.h> //inet_addr
#include <netinet/in.h>

#include "DataBase.h"

#define KVS_AUTH_PATH "/tmp/KVS_Auth_socket"

#define GROUP_ID_SIZE 8
#define SECRET_SIZE 10

#define AUTH_DATA_BASE "AuthDataBase"

#define SERVER_PORT 4000 // http


int authentication_protocol(char *msg)
{
    int result = 0;

    char *group = (char *)malloc(sizeof(char) * (GROUP_ID_SIZE + 1));

    char *secret = (char *)malloc(sizeof(char) * (SECRET_SIZE + 1));

    sscanf(msg, "a %s %s", group, secret);

    printf("Authentication: %s %s\n", group, secret);

    result = exists_in_data_base(AUTH_DATA_BASE, group, secret);

    if (result == 0 && insert_in_data_base(AUTH_DATA_BASE, group, secret) != 0)
    {
        print_data_base();
        free(group);
        free(secret);
        return 1;
    }
    print_data_base();
    free(group);
    free(secret);

    return result;
}

int create_group_protocol(char *request)
{
    int result = 0;
    char* group_id = NULL;
    char* secret = NULL;
    
    group_id = (char*)malloc(sizeof(char)* (GROUP_ID_SIZE +1));
    if(group_id == NULL)
    {
        return -1;
    }

    secret = (char*)malloc(sizeof(char)* (SECRET_SIZE +1));
    if(secret == NULL)
    {   
        free(group_id);
        return -2;
    }
        
    sscanf(request, "c %s %s", group_id, secret);

    printf("Auth-server: create received %s %s\n", group_id, secret);
    
    result = exists_in_data_base(AUTH_DATA_BASE, group_id, secret);

    if (result == 0 && insert_in_data_base(AUTH_DATA_BASE, group_id, secret) != 0)
    {
        print_data_base();
        free(group_id);
        free(secret);
        return 1;
    }

    print_data_base();
    free(group_id);
    free(secret);

    return result;
}

int delete_group_protocol(char *request)
{
    char *group_id = NULL;

    group_id = (char*)malloc(sizeof(char)* (GROUP_ID_SIZE +1));
    if(group_id == NULL)
    {
        return -1;
    }

    sscanf(request, "d %s", group_id);

    if (remove_from_data_base(AUTH_DATA_BASE, group_id) != 0)
    {
        free(group_id);
        return -2;
    }
    
    return 0;
}

int show_group_info_protocol(int sock_fd, struct sockaddr_in reply_addr, char *request)
{
    char *group_id = NULL;
    char* secret = NULL;
    char buffer[64];
    char failure[] = "FAILURE";
        
    memset(buffer,0,64);

    group_id = (char*) malloc(sizeof(char) * (GROUP_ID_SIZE + 1));
    if(group_id == NULL)
    {
        if (sendto(sock_fd, failure, strlen(failure) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
        {
            printf("Failed to sendto failure\n");
            return -1;
        }
        return -2;
    }

   sscanf(request,"s %s",group_id);

    secret = get_in_data_base(AUTH_DATA_BASE, group_id);
    if (secret == NULL)
    {
        if (sendto(sock_fd, failure, strlen(failure) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
        {
            printf("Failed to sendto failure\n");
            return -3;
        }
        free(group_id);
        return -4;
    }

    sprintf(buffer, "SUCCESS %s", secret);

    if (sendto(sock_fd, buffer, strlen(buffer) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
    {
        printf("Failed to sendto success\n");
        free(group_id);
        return -5;
    }

    free(group_id);

    return 0;
}

int request_processor(int sock_fd, struct sockaddr_in reply_addr, char *request)
{   
    char success[] = "SUCCESS";
    char failure[] = "FAILURE";

    switch(request[0])
    {   
        
        case 'a':
             printf("Autho-Server: Authenticating client...\n");

             if (authentication_protocol(request) % 2 == 0)
             {  
                printf("Sended Success\n");
                if (sendto(sock_fd, success, strlen(success) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto success\n");
                    return -1;
                }
             }
             else
             {
                printf("Sended failure\n");
                if (sendto(sock_fd, failure, strlen(failure) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto failure\n");
                    return -2;
                }
             }

            break;
        case 'c':

            if (create_group_protocol(request) % 2 == 0)
            {
                printf("Autho-Server: Group created\n");
                if (sendto(sock_fd, success, strlen(success) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto success\n");
                    return -3;
                }
            }
            else
            {
                printf("Sended failure\n");
                if (sendto(sock_fd, failure, strlen(failure) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto failure\n");
                    return -4;
                }
                return -5;
            }

            break;
        case 'd':

            if (delete_group_protocol(request) == 0)
            {
                printf("Autho-Server: Group deleted\n");
                print_data_base();
                if (sendto(sock_fd, success, strlen(success) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto success\n");
                    return -5;
                }
            }
            else
            {
                if (sendto(sock_fd, failure, strlen(failure) + 1, 0, (struct sockaddr *)&reply_addr, sizeof(reply_addr)) < 0)
                {
                    printf("Failed to sendto failure\n");
                    return -6;
                }
            }

            break;
        case 's':

            if (show_group_info_protocol(sock_fd, reply_addr, request) != 0)
            {
                printf("Autho-Server: Failed to reply group inf0\n");
                return -7;
            }

            break;
        default:
            return -8;
            break;
    
    }

    return 0;
}

int main()
{
    char buffer[512];
    memset(buffer, 0, 512);
    buffer[511] = '\0';

    printf("Inicializing...\n");

    // Variables needed to use the server socket
    int sock_desc, nbytes, flag, err;
    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;
    socklen_t client_size = sizeof(client_addr);

    // create socket

    sock_desc = socket(AF_INET, SOCK_DGRAM, 0);
    if (sock_desc < 0)
    {
        printf("Could not create socket\n");
        exit(EXIT_FAILURE);
    }
    printf("Auth-server: Socket Created...\n");
    //Prepare

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_aton("192.168.1.19", &server_addr.sin_addr);
    //server_addr.sin_addr.s_addr = INADDR_ANY;

    /*server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_aton("192.168.1.28", &server_addr.sin_addr);*/

    if (-1 == setsockopt(sock_desc, SOL_SOCKET, SO_REUSEADDR, &flag, sizeof(flag)))
    {
        perror("setsockopt fail");
    }

    //Bind
    err = bind(sock_desc, (struct sockaddr *)&server_addr, sizeof(server_addr));
    if (err < 0)
    {
        printf("could not bind the socket\n");
        exit(EXIT_FAILURE);
    }

    printf("autho-server: Socket created and binded \n and ready to accept connections...\n");

    //To get the ip address of the connected client
    char *client_ip_address = inet_ntoa(client_addr.sin_addr);
    int client_port = ntohs(client_addr.sin_port);


    // Server read to recv request from the client
    while (1)
    {

        nbytes = recvfrom(sock_desc, &buffer, 511, 0, (struct sockaddr *)&client_addr, &client_size);
        if (nbytes < 0)
        {
            printf("Could not receive the data from Local Server\n");
            break;
        }

        printf("Autho-Server: Received %d bytes from %s at port %d --%s--\n", nbytes, client_ip_address, client_port, buffer);

        sleep(1);

        if(request_processor(sock_desc,client_addr,buffer) != 0)
        {
            printf("Auth-Server: request not handle\n");
        }
    }

    close(sock_desc);

    exit(EXIT_SUCCESS);
}

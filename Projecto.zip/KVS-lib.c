#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/types.h>

#include "KVS-lib.h"

#define KVS_SOCKET_PATH "/tmp/KVS_Local_socket"

#define MODE_CONNECT 0
#define MODE_PUT 1
#define MODE_GET 2
#define MODE_REMOVE 3
#define MODE_CALLBACK 4
#define MODE_DISCONNECT 5

#define SECRET_SIZE 10
#define kEY_SIZE 6
#define GROUP_ID_SIZE 8

// Data type that stores poiter to function that is going to be run by register_callback
typedef void (*functiontype)(char *);

// Data structure that the callback funcion takes is arguments from
typedef struct _thread_args
{
    functiontype func;
    char *key;
    char* sock_path;
} thread_args;

// Stores a thread id, so that different callback uses diferent sockets to comunicate with the local server
int pseudo_thread_id = 0;

// Stores the current error
int current_error = 0;

// KVS Local Server address
const struct sockaddr_un KVS_local_addr = {AF_UNIX,KVS_SOCKET_PATH};

// Client socket handler
int client_socket = 0;

// Path to the client socket
char* client_socket_path = NULL;

// Client socket address path
struct sockaddr_un client_socket_addr;

// Handle the register callback, TODO make erro handling
void* handle_callback(void* args)
{
    thread_args *parameters = (thread_args*) args;
    int thread_socket = 0;
    char buffer[32];
    buffer[31] = '\0';

    struct sockaddr_un server_addr;
    socklen_t server_addr_size = 0;

    // Creates the address of the thread
    struct sockaddr_un thread_addr;
    thread_addr.sun_family = AF_UNIX;
    strcpy(thread_addr.sun_path, parameters->sock_path);

    // create socket for the thread
    thread_socket = socket(AF_UNIX, SOCK_DGRAM, 0);

    // Verify if the socket was Well created
    if (thread_socket == -1)
    {
        pthread_exit(NULL);
    }

    // Bind and address to the socket created above and check for error
    if (bind(thread_socket, (struct sockaddr *)&thread_addr, sizeof(thread_addr)) == -1)
    {
        pthread_exit(NULL);
    }

    // Waits for a response from the Local Server
    if (recvfrom(thread_socket, buffer, 31, 0, (struct sockaddr *)&server_addr, &server_addr_size) < 0)
    {
        pthread_exit(NULL);
    }

    printf("Client: Callback %s\n",buffer);

    // Waits to see if everthing went ok
    if(strstr(buffer,"SUCCESS") == NULL)
    {
        pthread_exit(NULL);
    }

    // Call the function passesd to the callback
    parameters->func(parameters->key);

    pthread_exit(NULL);
}

// function to receive data
char* client_recv(int client_fd)
{
    char buffer[512];
    buffer[511] = '\0';

    char *recv_msg = NULL;

    int size_recv = 0;
    int total_size = 0;

    memset(buffer, 0, 512);

    if ((size_recv = recv(client_fd, buffer, 512, 0)) <= 0)
    {
        return NULL;
    }

    printf("\tClient: %s\n\n", buffer);

    sscanf(buffer, "msg-notification %d", &total_size);

    recv_msg = (char *)malloc(sizeof(char) * total_size);
    memset(recv_msg, 0, total_size);

    if ((size_recv = recv(client_fd, recv_msg, total_size, 0)) <=0)
    {
        return NULL;
    }

    printf("\nMSG recv: %d %s\n\n", total_size, recv_msg);

    return recv_msg;
}

// Creates a path for client address
char* client_socket_path_creator(void)
{
    char* str_skt = NULL;

    // Allocate memory space
    str_skt = (char*) malloc(sizeof(char) * 108);
    // Verify if allocation went right
    if (str_skt == NULL)
    {
        // No memory available to create the client path
        return NULL;
    }
    // Creatss the client path
    sprintf(str_skt,"/tmp/KVS_client_socket_%d",getpid());

    return str_skt;
}

// Puts the data to send in the correct format
char *data_format(char *key, char *value, int mode)
{
    char *str = NULL;

    if (value == NULL && key != NULL)
    {
        str = (char *)malloc(sizeof(char) * (2 + strlen(key) + 1));
    }
    else if (value != NULL && key != NULL)
    {
        str = (char *)malloc(sizeof(char) * (3 + strlen(key) + strlen(value) + 1));
    }
    else if (value == NULL && key == NULL)
    {
        str = (char*) malloc(sizeof(char) * (1 + 1));
    }

    // Verify if str was allocated
    if (str == NULL)
    {
        return NULL;
    }

    // Implemets the diferent formats of data
    switch (mode)
    {
    case MODE_CONNECT:
        // Connect data format key corresponde a groupid e value corresponde a secret
        sprintf(str, "c %s %s", key, value);
        break;
    case MODE_PUT:
        // Put_value data format
        sprintf(str, "p %s %s", key, value);
        break;
    case MODE_GET:
        // Get_value data format
        sprintf(str, "g %s", key);
        break;
    case MODE_REMOVE:
        // delete_value data format
        sprintf(str, "r %s", key);
        break;
    case MODE_DISCONNECT:
        // disconect data format
        sprintf(str,"%s","d");
        break;
    case MODE_CALLBACK:
        // callback data format
        sprintf(str,"b %s %s", key, value);
        break;
    default:
        free(str);
        return NULL;
        break;
    }

    return str;
}

// Send any request to the KVS Local Server
int send_request(char *data)
{
    if (data == NULL)
    {
        // No data no send
        return -1;
    }

    char notification[512];
    notification[511] = '\0';

    sprintf(notification, "msg-notification %ld", strlen(data) + 1);

    // Notificates the server that will be an incoming msg of size n
    if (send(client_socket, notification, strlen(notification) + 1, 0) == -1) // +1 because of the '\0' caracter
    {
        // Failed to send the data
        return -2;
    }
    
    sleep(1);

    // Sends the request to the server
    if (send(client_socket, data, strlen(data) + 1, 0) == -1) // +1 because of the '\0' caracter
    {
        // Failed to send the data
        return -3;
    }

    return 0;
}

// Estabilish the connection between the client and the KVS Local Server
int establish_connection(char *group_id, char *secret)
{
    printf("Client: connecting...\n");

    // Check if the connection was already made
    if (client_socket < 0)
    {   
        // Connection already made
        return -1;
    }

    // Creats a path for the address of the client socket
    client_socket_path = client_socket_path_creator();
    if(client_socket_path == NULL)
    {
        // Memory not available to create a client socket
        return -2;
    }

    // Creates the client socket
    client_socket = socket(AF_UNIX, SOCK_STREAM, 0);

    // Verify if the creation went ok
    if (client_socket == -1)
    {   
        // Socket creation failed
        return -3;
    }

    // Creates the client socket address
    // memset(&client_socket_addr, 0 , sizeof(client_socket_addr));
    client_socket_addr.sun_family = AF_UNIX;
    strcpy(client_socket_addr.sun_path,client_socket_path);

    // Bind the socket with the address and verify if everything went ok
    if(bind(client_socket, (struct sockaddr*) &client_socket_addr,sizeof(client_socket_addr)) == -1)
    {
        // Failed to make bind
        return -4;
    }

    // Attemps to connect
    if (connect(client_socket, (struct sockaddr *)&KVS_local_addr, sizeof(KVS_local_addr)) == -1)
    {
        // Failed to connect to the server
        return -5;
    }

    char *data = NULL;
    char *status = NULL;

    // Formates the data to be sended
    data = data_format(group_id, secret, MODE_CONNECT);
    if (data == NULL)
    {
        return -6;
    }

    // Send the information to KVS Local Server
    if (send_request(data) != 0)
    {
        // Failed to send data
        return -7;
    }

    // Eliminates the data sended
    free(data);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);

    if(status == NULL)
    {
        return -8;
    }

    printf("Client: %s\n",status);
    // Now processes the information
    if(strstr(status,"SUCCESS") == NULL)
    {
        free(status);
        return -9;
    }

    printf("Client: connected\n");
    free(status);

    usleep(100);

    return 0;
}

// Sends the request to put a value in the server
int put_value(char *key, char *value)
{
    char* data = NULL;
    char* status = NULL;

    printf("Client: Putting...\n");

    // Check if the connection was already made
    if (client_socket < 0)
    {
        // Connection already made
        return -1;
    }

    // Check if client socket stil as a path
    if(client_socket_path == NULL)
    {
        // Connection already made
        return -2;
    }

    // Configures the data in the currect format to be sended
    data = data_format(key,value,MODE_PUT);
    if(data == NULL)
    {
        // Wrong data format or failed to alloc memmory
        return -3;
    }

    // Send the information to KVS Local Server
    if(send_request(data) != 0)
    {   
        // Failed to send data
        return -4;
    }

    // Eliminates the data sended
    free(data);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);

    if (status == NULL)
    {
        return -5;
    }

    // Processes gets request status and gives feedback to the user
     // Now processes the information
     
    if(strstr(status, "SUCCESS") == NULL)
    {
        free(status);
        return -6;
    }

    free(status);

    printf("Client: Put sucess\n");


    return 0;
}

// Sends the request to get a value from the server
int get_value(char * key, char ** value)
{
    
    //check for connection
    char* data = NULL;
    char* status = NULL;
    char* buffer = NULL;

    if(client_socket < 0)
    {
        return -1;
    }

    // Check if client socket stil as a path
    if(client_socket_path == NULL)
    {
        // Connection already made
        return -2;
    }
    
    if (strlen(key) == 0)
    {
        fprintf(stderr, "get_Value needs a key\n");
        return -3;
    }

    // Formates the data to be sended
    data = data_format(key, NULL, MODE_GET);
    if (data == NULL)
    {
        return -4;
    }

    // Send the information to KVS Local Server
    if (send_request(data) != 0)
    {
        // Failed to send data
        return -5;
    }

    // Eliminates the data sended
    free(data);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);

    if (status == NULL)
    {
        return -6;
    }

    // Processes tge request status and gives feedback to the user
     // Now processes the information
    
    if(strstr(status,"SUCCESS") == NULL)
    {
        free(status);
        return -7;
    }

    // DEPOIS DE RECEBER OS DADOS RETURNALOS PARA P USER
    buffer = (char *)malloc(sizeof(char) * (strlen(status) - 8 +1));

    if (buffer == NULL)
    {
        return -8;
    }

    sscanf(status, "SUCCESS %[^\n]", buffer);

    *value = buffer;

    free(status);

    printf("get_value sucess\n");
    

    return 0;
}

// Sends the request to remove a value from the server
int delete_value(char * key)
{
    char *data = NULL;
    char *status = NULL;

    if (client_socket < 0)
    {
        return -1;
    }

    // Check if client socket stil as a path
    if(client_socket_path == NULL)
    {
        // Connection already made
        return -2;
    }

    if (strlen(key) == 0){
        fprintf(stderr, "get_Value needs a key\n");
        return -3;
    }

    data = data_format(key, NULL, MODE_REMOVE);
    if (data == NULL)
    {
        return -4;
    }
    
    // Send the information to KVS Local Server
    if (send_request(data) != 0)
    {
        // Failed to send data
        return -5;
    }

    // Elimenates the data sended
    free(data);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);

    if (status == NULL)
    {
        return -6;
    }

    // !TODO [PARA IMPLEMENTAR QUANDO FIZERMOS CODIGO PARA VERIFICAR KEY E VALUE]

    if(strstr(status,"SUCCESS") == NULL)
    {
        free(status);
        return -7;
    }
    printf("Delete sucess\n");
    
    free(status);
    // Processes tge request status and gives feedback to the user

    return 0;
}

// Sends a request to set a trigger when key's value is altered
int register_callback(char *key, void (*callback_function)(char *))
{
    char *data = NULL;
    char *status = NULL;
    char* t_sock_path = NULL;
    char* t_id = NULL;
    pthread_t thread_id;
    thread_args* parameters = NULL;

    printf("Client: Setting CallBack...\n");

    // Check if the connection was already made
    if (client_socket < 0)
    {
        // Connection already made
        return -1;
    }

    // Check if client socket stil as a path
    if (client_socket_path == NULL)
    {
        // Connection already made
        return -2;
    }

    t_id = (char*) malloc(sizeof(char) * 12);

    sprintf(t_id,"_%d",pseudo_thread_id);
    pseudo_thread_id++;

    t_sock_path = client_socket_path_creator();

    strcat(t_sock_path,t_id);

    // Configures the data in the currect format to be sended
    data = data_format(key, t_sock_path, MODE_CALLBACK);
    if (data == NULL)
    {
        // Wrong data format or failed to alloc memmory
        return -3;
    }

    // Send the information to KVS Local Server
    if (send_request(data) != 0)
    {
        // Failed to send data
        return -4;
    }

    // Eliminates the data sended
    free(data);

    free(t_id);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);
    if (status == NULL)
    {
        return -5;
    }

    // Processes gets request status and gives feedback to the user
    // Now processes the information

    if (strstr(status, "SUCCESS") == NULL)
    {
        free(status);
        return -6;
    }

    free(status);

    // Thread that waits for the callback and comunicates with the other thread in local_server
    parameters = (thread_args*) malloc(sizeof(thread_args));
    if(parameters == NULL)
    {
        return -7;
    }

    parameters->func = callback_function;
    parameters->key = key;
    parameters->sock_path = t_sock_path;

    if (pthread_create(&thread_id, NULL, handle_callback, parameters) != 0)
    {
        return -8;
    }

    printf("Client: CallBack Set\n");

    sleep(1);

    return 1;
}

// Closes the connection with the server
int close_connection(void)
{
    printf("Client: Closing connection...\n");
    
    char* data = NULL;
    char* status = NULL;

    // In case there is no socket created
    if (client_socket < 0)
    {
        return -1;
    }
    
    // In case there is no client socket path
    if(client_socket_path == NULL)
    {
        return -2;
    }

    // Send request to a server 
    data = data_format(NULL, NULL, MODE_DISCONNECT);
    if(data == NULL)
    {
        // Wrong data format or failed to alloc memmory
        return -3;
    }

    // Send the information to KVS Local Server
    if (send_request(data) != 0)
    {
        // Failed to send data
        return -4;
    }

    // Elimenates the data sended
    free(data);

    // Wait for the KVS Local Server to report the status of the request
    status = client_recv(client_socket);

    if (status == NULL)
    {
        return -5;
    }


    if(strstr(status,"SUCCESS") == NULL)
    {
        free(status);
        return -6;
    }

    free(status);

    printf("Disconnect sucess\n");

    // Reset all relevant variables and frees some memory
    close(client_socket);
    client_socket = 0;
    unlink(client_socket_path);
    free(client_socket_path);
    current_error = 0;

    printf("Client: Connection closed\n");

    return 0;
}
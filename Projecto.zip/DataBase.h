#ifndef _DATA_BASE_H_
#define _DATA_BASE_H_

int insert_in_data_base(char *group_id, char *key , char *value);
char* get_in_data_base(char *group_id, char *key);
int remove_from_data_base(char* group_id, char *key);
int exists_in_data_base(char *group_id, char *key, char *value);
int remove_group_from_data_base(char* group_id);
int delete_data_base();
void print_data_base();
int group_size_from_data_base(char *group_id);


#endif
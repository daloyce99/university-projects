#include <sys/socket.h>
#include <sys/un.h>
#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <ctype.h>
#include <time.h>

#include "DataBase.h"

#define KVS_SOCKET_PATH "/tmp/KVS_Local_socket"

#define BACKLOG 10
#define QUIT 0

#define SECRET_SIZE 10
#define kEY_SIZE 6
#define GROUP_ID_SIZE 8

#define USER_LIMIT 100

int local_to_auth_socket = 0;
struct sockaddr_in auth_server_addr;

// Data structure that the callback funcion takes is arguments from
typedef struct _thread_args
{
    char* group_id;
    char *key;
    char *sock_path;
} thread_args;

// function to receive data
char *server_recv(int client_fd)
{
    char buffer[512];
    buffer[511] = '\0';

    char *recv_msg = NULL;

    int total_size = 0;
    int size_recv = 0;

    memset(buffer, 0, 512);

    if ((size_recv = recv(client_fd, buffer, 512, 0)) <= 0)
    {
        return NULL;
    }

    printf("Server: %s\n", buffer);

    sscanf(buffer, "msg-notification %d", &total_size);

    recv_msg = (char *)malloc(sizeof(char) * total_size);
    memset(recv_msg, 0, total_size);

    if ((size_recv = recv(client_fd, recv_msg, total_size, 0)) <= 0)
    {
        return NULL;
    }

    printf("Server: Received %s %d\n\n", recv_msg, total_size);

    return recv_msg;
}

// Sends an information to a client return 0 in case of success and -x* in case of erros
int server_reply(int client_fd, char* info)
{
    char buffer[512];
    buffer[511] = '\0';

    memset(buffer, 0, 511);

    sprintf(buffer,"msg-notification %ld",strlen(info) + 1);

    if (send(client_fd, buffer, strlen(buffer) + 1, 0) < 0)
    {
        perror("Error: Server couldn't reply");
        return -1;
    }

    sleep(1);

    if (send(client_fd, info, strlen(info) + 1,0) < 0)
    {
        perror("Error: Server couldn't reply");
        return -1;
    }

    printf("Server: Replys %s\n", info);

    return 0;
}

// Processes the authentication process
int authentication(char *group, char *secret)
{
    socklen_t size_recv = 0;

    char *str = (char *)malloc(sizeof(char) * (GROUP_ID_SIZE + SECRET_SIZE + 3 + 1));
    if (str == NULL)
    {
        return -1;
    }

    str[GROUP_ID_SIZE + SECRET_SIZE + 3] = '\0';

    sprintf(str, "a %s %s", group, secret);

    printf("Authentication: %s to %s:%d\n", str, inet_ntoa(auth_server_addr.sin_addr), auth_server_addr.sin_port);

    if (sendto(local_to_auth_socket, str, GROUP_ID_SIZE + SECRET_SIZE + 3 + 1, 0, (struct sockaddr *)&auth_server_addr, sizeof(auth_server_addr)) < 0)
    {
        return -2;
    }

    memset(str, 0, GROUP_ID_SIZE + SECRET_SIZE + 3);

    if (recvfrom(local_to_auth_socket, str, GROUP_ID_SIZE + SECRET_SIZE + 3 + 1, 0, (struct sockaddr *)&auth_server_addr, &size_recv) < 0)
    {
        return -3;
    }

    if (strstr(str, "SUCCESS") == NULL)
    {
        return -4;
    }

    return 0;
}

// makes the connection procediments
int connection_protocol(char* request, int client_skt,char** client_group_id)
{
    char* key_group_id = NULL;
    char* value_secret = NULL;

    key_group_id = (char *)malloc(sizeof(char) * (GROUP_ID_SIZE + 1));
    if (key_group_id == NULL)
    {
        return -1;
    }

    value_secret = (char *)malloc(sizeof(char) * (SECRET_SIZE + 1));
    if (value_secret == NULL)
    {
        free(key_group_id);
        return -2;
    }

    sscanf(request, "c %s %s", key_group_id, value_secret);

    // verification of client TODO
    if (authentication(key_group_id, value_secret) != 0)
    {
        // Sends feedback to client
        server_reply(client_skt, "FAILURE");

        printf("Server: Client not connected\n \tAuthentication Failed\n");

        free(key_group_id);
        free(value_secret);

        return -3;
    }

    *client_group_id = key_group_id;

    // Sends feedback to client
    server_reply(client_skt, "SUCCESS");

    free(value_secret);

    return 0;
}

// makes the put_value procediments
int put_value_protocol(char* request, int client_skt, char* client_group_id)
{
    char *key_group_id = NULL;
    char *value_secret = NULL;

    key_group_id = (char *)malloc(sizeof(char) * (kEY_SIZE + 1));
    if (key_group_id == NULL)
    {
        return -1;
    }

    value_secret = (char *)malloc(sizeof(char) * (strlen(request) - kEY_SIZE - 3 + 1));
    if (value_secret == NULL)
    {
        return -2;
    }

    sscanf(request, "p %s %[^\n]", key_group_id, value_secret);

    printf("Server at put processing:\n\t value_secret = %s %ld\n", value_secret, (strlen(request) - kEY_SIZE - 3 + 1));

    if (insert_in_data_base(client_group_id, key_group_id, value_secret) != 0)
    {
        // Em caso de falha
        server_reply(client_skt, "FAILURE");
        return -3;
    }

    // Sends feedback to client
    server_reply(client_skt, "SUCCESS");

    // Prints data base
    printf("Server: Data Base\n");
    print_data_base();

    free(key_group_id);
    free(value_secret);

    return 0;
}

// makes the get_value procediments
int get_protocol(char* request, int client_skt, char* client_group_id)
{
    char *key_group_id = NULL;
    char *value = NULL;
    char *buffer = NULL;

    key_group_id = (char *)malloc(sizeof(char) * (kEY_SIZE + 1));
    if (key_group_id == NULL)
    {
        return -1;
    }

    sscanf(request, "g %s", key_group_id);

    value = get_in_data_base(client_group_id, key_group_id);
    if (value == NULL)
    {
        // Em caso de falha
        server_reply(client_skt, "FAILURE");
        return -3;
    }

    buffer = (char *)malloc(sizeof(char) * (strlen(value) + 1 + 7));
    if (buffer == NULL)
    {
        // Em caso de falha
        server_reply(client_skt, "FAILURE");
        return -4;
    }

    sprintf(buffer, "SUCCESS %s", value);

    // Sends feedback to client
    server_reply(client_skt, buffer);

    // Prints data base
    printf("Server: Data Base\n");
    print_data_base();

    free(key_group_id);
    free(buffer);

    return 0;
}

// makes the remove_value procediments
int remove_protocol(char* request,int client_skt, char* client_group_id)
{
    char *key_group_id = NULL;

    key_group_id = (char *)malloc(sizeof(char) * (kEY_SIZE + 1));
    if (key_group_id == NULL)
    {
        return -1;
    }

    sscanf(request, "r %s", key_group_id);

    if (remove_from_data_base(client_group_id, key_group_id) != 0)
    {
        // Se o processo falhar
        server_reply(client_skt, "FAILURE");
        return -2;
    }

    // Sends feedback to client
    server_reply(client_skt, "SUCCESS");

    // Prints data base
    printf("Server: Data Base\n");
    print_data_base();

    free(key_group_id);

    return 0;
}

// thread that handles one callback request
void* handle_callback(void* args)
{
    thread_args *parameters = (thread_args *)args;
    int thread_socket = 0;
    char success[] = "SUCCESS";
    char failure[] = "FAILURE";
    char* begin_value = NULL;
    char* tmp = NULL;
    // Creates the address of the thread
    struct sockaddr_un client_thread_addr;
    client_thread_addr.sun_family = AF_UNIX;
    strcpy(client_thread_addr.sun_path, parameters->sock_path);

    // create socket for the thread
    thread_socket = socket(AF_UNIX, SOCK_DGRAM, 0);

    // Verify if the socket was Well created
    if (thread_socket == -1)
    {
        // Sends failure to the server
        if (sendto(thread_socket, failure, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
        {
            free(parameters->key);
            free(parameters->sock_path);
            pthread_exit(NULL);
        }

        free(parameters->key);
        free(parameters->sock_path);
        pthread_exit(NULL);
    }

    // Checks if the client is still connected
    if (parameters->group_id == NULL)
    {
        // Sends failure to the server
        if (sendto(thread_socket, failure, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
        {
            free(parameters->key);
            free(parameters->sock_path);
            pthread_exit(NULL);
        }

        free(parameters->key);
        free(parameters->sock_path);
        pthread_exit(NULL);
    }

    // Gets most recent value
    tmp = get_in_data_base(parameters->group_id, parameters->key);
    if(tmp == NULL)
    {
        // Sends failure to the server
        if (sendto(thread_socket, failure, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
        {
            free(parameters->key);
            free(parameters->sock_path);
            pthread_exit(NULL);
        }

        free(parameters->key);
        free(parameters->sock_path);
        pthread_exit(NULL);
    }

    // Necessery to make the comparisons
    begin_value = (char*) malloc(sizeof(char) * (strlen(tmp) + 1));
    if(begin_value == NULL)
    {
        // Sends failure to the server
        if (sendto(thread_socket, failure, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
        {
            free(parameters->key);
            free(parameters->sock_path);
            pthread_exit(NULL);
        }
        free(parameters->key);
        free(parameters->sock_path);
        pthread_exit(NULL);
    }

    // Stores the first value to compare alterations
    strcpy(begin_value,tmp);

    // Looks for an alteration in the value
    while (parameters->group_id != NULL)
    {   
        // Gets the most recent value
        tmp = get_in_data_base(parameters->group_id, parameters->key);
        if (tmp == NULL)
        {
            // Sends failure to the server
            if (sendto(thread_socket, failure, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
            {
                free(parameters->key);
                free(parameters->sock_path);
                pthread_exit(NULL);
            }

            free(parameters->key);
            free(parameters->sock_path);
            pthread_exit(NULL);
        }

        if(strcmp(begin_value,tmp) != 0)
        {
            break;
        }
    }

    // Sends success to the server
    if (sendto(thread_socket, success, 31, 0, (struct sockaddr *)&client_thread_addr, sizeof(client_thread_addr)) < 0)
    {
        free(parameters->key);
        free(parameters->sock_path);
        pthread_exit(NULL);
    }

    printf("Server: Callback triggered\n");

    // Free the key, otherwise we lose memory
    free(parameters->key);
    free(parameters->sock_path);

    pthread_exit(NULL);
}

// makes the register_callback_protocol
int register_callback_protocol(char* request,int client_skt, char* client_group_id)
{
    char* key = NULL;
    char* client_thread_path = NULL;
    thread_args *parameters = NULL;
    pthread_t thread_id;

    key = (char*) malloc(sizeof(char) * (kEY_SIZE + 1));
    if(key == NULL)
    {
        return -1;
    }

    client_thread_path = (char*) malloc(sizeof(char) * (strlen(request) - kEY_SIZE - 3 + 1));
    if(client_thread_path == NULL)
    {
        return -2;
    }

    sscanf(request,"b %s %s",key,client_thread_path);

    parameters = (thread_args*) malloc(sizeof(thread_args));
    if(parameters == NULL)
    {
        return -3;
    }

    parameters->group_id = client_group_id;
    parameters->key = key;
    parameters->sock_path = client_thread_path;

    if (pthread_create(&thread_id, NULL, handle_callback,(void*) parameters) != 0)
    {
        return -4;
    }

    if(server_reply(client_skt,"SUCCESS") != 0)
    {
        return -5;
    }

    return 0;
}

char* secrete_generator(void)
{
    static char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789,.-#'?!";        
    char *randomString = NULL;

    randomString = malloc(sizeof(char) * (SECRET_SIZE + 1));

    if (randomString != NULL)
    {            
        for (int n = 0;n < SECRET_SIZE;n++) {            
            int key = rand() % (int)(sizeof(charset) -1);
            randomString[n] = charset[key];
        }

        randomString[SECRET_SIZE] = '\0';
    }
    else
    {
        return NULL;
    }

    return randomString;
}

int ui_create_group_protocol(char * ui_request)
{
    char *group_id = NULL;
    char*secret = NULL ;
    char buffer[64];
    socklen_t addr_size = 0;
    struct sockaddr_in recv_addr;
    
    group_id = (char*)malloc(sizeof(char)*(GROUP_ID_SIZE +1));
    if (group_id == NULL)
    {
        return -1;
    }
    
    sscanf(ui_request, "Create %s", group_id);

    secret = secrete_generator();
    if(secret == NULL)
    {   
        free(group_id);
        return -2;
    }

    memset(buffer,0,64);

    sprintf(buffer, "c %s %s", group_id, secret);

    if(sendto(local_to_auth_socket, buffer, 2 + GROUP_ID_SIZE + SECRET_SIZE + 1,0, (struct sockaddr*) &auth_server_addr,sizeof(auth_server_addr)) < 0)
    {
        printf("UI Processor: Not able to send msg to authentication server\n");
        free(secret);
        free(group_id);
        return -3;
    }

    memset(buffer,0,64);

    if (recvfrom(local_to_auth_socket, buffer, 63, 0, (struct sockaddr *)&recv_addr, &addr_size) < 0)
    {
        printf("UI Processor: Not able to recv msg to authentication server\n");
        free(secret);
        free(group_id);
        return -4;
    }

    printf("buffer in creating group: %s\n",buffer);

    if(strstr(buffer,"SUCCESS") == NULL)
    {
        printf("UI Processor: Error in authentication server\n");
        free(secret);
        free(group_id);
        return -5;
    }

    printf("%s\n",secret);

    if(insert_in_data_base(group_id,NULL,NULL) != 0)
    {
        return -6;
    }

    free(secret);
    free(group_id);

    return 0;
}

int ui_delete_group_protocol(char *ui_request)
{
    char *group_id = NULL;
    char buffer[64];
    socklen_t addr_size = 0;
    struct sockaddr_in recv_addr;

    group_id = (char *)malloc(sizeof(char) *(GROUP_ID_SIZE +1));
    if (group_id == NULL)
    {
        return -1;
    }

    sscanf(ui_request, "Delete %s", group_id);

    memset(buffer, 0, 64);

    sprintf(buffer, "d %s", group_id);

    if (sendto(local_to_auth_socket, buffer, 2 + GROUP_ID_SIZE + SECRET_SIZE + 1, 0, (struct sockaddr *)&auth_server_addr, sizeof(auth_server_addr)) < 0)
    {
        printf("UI Processor: Not able to send msg to authentication server\n");
        free(group_id);
        return -3;
    }

    memset(buffer, 0, 64);

    if (recvfrom(local_to_auth_socket, buffer, 63, 0, (struct sockaddr *)&recv_addr, &addr_size) < 0)
    {
        printf("UI Processor: Not able to recv msg to authentication server\n");
        free(group_id);
        return -4;
    }

    if (strstr(buffer, "SUCCESS") == NULL)
    {
        printf("UI Processor: Error in authentication server\n");
        free(group_id);
        return -5;
    }

    if(remove_group_from_data_base(group_id) != 0)
    {
        printf("UI Processor: NOt able to remove group from database\n");
        free(group_id);
        return -6;
    }

    free(group_id);

    return 0;
}

int ui_show_group_info_protocol(char * ui_request)
{
    char *group_id = NULL;
    char *secret = NULL;
    char buffer[64];
    socklen_t addr_size = 0;
    struct sockaddr_in recv_addr;

    group_id = (char*)malloc(sizeof(char)*(GROUP_ID_SIZE + 1));
    if (group_id == NULL)
    {
        return -1;
    }

    sscanf(ui_request, "Show %s info", group_id);

    secret = (char*)malloc(sizeof(char)*(SECRET_SIZE + 1));
    if (secret == NULL)
    {
        return -2;
    }

    memset(buffer, 0, 64);

    sprintf(buffer,"s %s",group_id);    

    if (sendto(local_to_auth_socket, buffer, 2 + GROUP_ID_SIZE + SECRET_SIZE + 1, 0, (struct sockaddr *)&auth_server_addr, sizeof(auth_server_addr)) < 0)
    {
        printf("UI Processor: Not able to send msg to authentication server\n");
        free(group_id);
        return -3;
    }

    memset(buffer, 0, 64);

     if (recvfrom(local_to_auth_socket, buffer, 63, 0, (struct sockaddr *)&recv_addr, &addr_size) < 0)
    {
        printf("UI Processor: Not able to recv msg to authentication server\n");
        free(secret);
        free(group_id);
        return -4;
    }

    if(strstr(buffer,"SUCCESS") == NULL)
    {
        printf("UI Processor: Error in authentication server\n");
        free(secret);
        free(group_id);
        return -5;
    }

    sscanf(buffer,"SUCCESS %s",secret);

    printf("secret: %s\n number of key-value pairs: %d\n", secret, group_size_from_data_base(group_id));

    free(secret);
    free(group_id);

    return 0;
}

/*int ui_show_aplication_status(char * ui_request)
{   
    time_t conec
    
    socklen_t addr_size = 0;
    struct sockaddr_in recv_addr;

}*/

int ui_request_processor(char *ui_request)
{
    if(strstr(ui_request,"Create") != NULL)
    {
        if(ui_create_group_protocol(ui_request) != 0)
        {
            return -1;
        }
    }
    else if (strstr(ui_request,"Delete") != NULL)
    {
        if (ui_delete_group_protocol(ui_request) != 0)
        {
            return -2;
        }
    }
    else if (strstr(ui_request, "Show") != NULL && strstr(ui_request, "info"))
    {
        if (ui_show_group_info_protocol(ui_request) != 0)
        {
            return -3;
        }
    }
    else if (strstr(ui_request,"Show aplication status") != NULL)
    {   

        printf("Not implemented\n");
        /*if (ui_show_aplication_status(ui_request) != 0)
        {
            return -4;
        }*/
    }
    else
    {
        printf("Ui Processor: Command not found\n");
        return -5;
    }

    return 0;
}

// UI
void *thread_handler_UI(void *args)
{
    char* buffer = NULL;
    size_t size_buffer = 1;
    do
    {
        if (getline(&buffer,&size_buffer,stdin) >= 0)
        {
            if (ui_request_processor(buffer) != 0)
            {
                printf("Ui Processor: Not able to process request\n");
            }
        }

    } while (strcmp(buffer,"quit") != 0);
    
    pthread_exit(NULL);
}

// check the client request and processes it
int request_processor(char* request, int client_skt, char** client_group_id)
{ 
    switch (request[0])
    {
        case 'c':
            printf("Server: Connecting client...\n");

            if(connection_protocol(request,client_skt,client_group_id) != 0)
            {
                printf("Server: Client not connected\n");
                return -1;   
            }

            printf("Server: Client connected\n");

            break;
        case 'p':
            printf("Server: Putting data...\n");

            if(put_value_protocol(request,client_skt, *client_group_id) != 0)
            {
                printf("Server: Data not putted\n");
                return -2;
            }

            printf("Server: Data putted\n");

            break;
        case 'g':
            printf("Server: Getting data...\n");
            
            if(get_protocol(request,client_skt,*client_group_id) != 0)
            {
                printf("Server: Not able to delivere data\n");
                return -3;
            }

            printf("Server: Data delivered\n");
            
            break;
        case 'r':
            printf("Server: Removing data...\n");
            
            if(remove_protocol(request,client_skt,*client_group_id) != 0)
            {
                printf("Server: Not able to remove data\n");
                return -4;
            }

            printf("Server: Data removed\n");

            break;
        case 'd':
            printf("Server: Disconnecting client ...\n");

            *client_group_id = NULL;

            // server deletes data base
            //delete_data_base();

            // Sends feedback to client
            server_reply(client_skt, "SUCCESS");

            printf("Server: Client Disconnected\n");

            // Prints data base
            printf("Server: Data Base\n");
            print_data_base();

            break;
        case 'b':

            printf("Server: Preparing callback...\n");

            if(register_callback_protocol(request,client_skt,*client_group_id) != 0)
            {
                printf("Server: Not able to make callback\n");
                return -5;
            }

            printf("Server: Callbak prepared\n");

            break;
        default:
            // Sends feedback to client
            server_reply(client_skt, "FAILURE");
            return -6;
            break;
    }

    return 0;
}

// thread that handles one client
void* handle_request(void *arg)
{
    char* data_recv = NULL;
    char* client_group_id = NULL;
    int local_sock = *(int*)arg;
    
    printf("Server: New thread created -> Local socket %d\n",local_sock);
    do
    {
        // Recives the user data
        data_recv = server_recv(local_sock);

        if(data_recv != NULL)
        {
            printf("Server: %s\n", data_recv);

            // Handle the client request
            request_processor(data_recv, local_sock,&client_group_id);

            free(data_recv);
        }
        
        // Verifies if the socket is still connected
    } while (client_group_id != NULL);

    pthread_exit(NULL);
}

int main() 
{
    int sock_fd = -1, client_fd = -1, err = 0;
    struct sockaddr_un local_server_addr;
    struct sockaddr_un app_client_addr;
    socklen_t size_addr = -1;
    pthread_t thread_id = -1;
    pthread_t ui_thread_id = -1;
    int pt;
    size_addr = sizeof(app_client_addr);

    struct sockaddr_in local_to_auth_addr;

    // Local server INet address
    local_to_auth_addr.sin_family = AF_INET;
    local_to_auth_addr.sin_port = htons(3000);
    //inet_aton("192.168.1.19", &local_to_auth_addr.sin_addr);
    local_to_auth_addr.sin_addr.s_addr = INADDR_ANY;

    // KVS-AuthServer Inet Address
    auth_server_addr.sin_family = AF_INET;
    auth_server_addr.sin_port = htons(4000);
    inet_aton("192.168.1.19", &auth_server_addr.sin_addr);
    //auth_server_addr.sin_addr.s_addr = INADDR_ANY;

    // Creates socket to comunicate with the authentication server
    local_to_auth_socket = socket(AF_INET, SOCK_DGRAM, 0);
    if (local_to_auth_socket == -1)
    {
        printf("Could not create socket\n");
        exit(-1);
    }

    // bind the socket to an address
    if (bind(local_to_auth_socket, (struct sockaddr *)&local_to_auth_addr, sizeof(local_to_auth_addr)) == -1)
    {
        printf("Could not bind socket auth_socket\n");
        exit(-1);
    }

    // create socket
    sock_fd = socket(AF_UNIX, SOCK_STREAM, 0);
    if ( sock_fd == -1){
        printf("Could not create socket\n");
        exit(-1);
    }
    else {
        printf("Socket successfully created\n");
    }

    //zeroing local_server_addr structure
    memset(&local_server_addr, 0, sizeof(local_server_addr));
    local_server_addr.sun_family = AF_UNIX;
    strcpy(local_server_addr.sun_path,KVS_SOCKET_PATH);

    unlink(KVS_SOCKET_PATH);

    // bind the socket to an address
    err = bind(sock_fd, (struct sockaddr*)&local_server_addr, sizeof(local_server_addr));
    if (err == -1){
        printf("Could not bind socket\n");
        exit(-1);
    }

    printf(" socket created and binded \n");

    // Sets server socket to listen connections attempts
    if (listen(sock_fd, BACKLOG) == -1){
        perror("Listen");
        exit(-1);
    }

    // Runs UI thread
    if (pthread_create(&ui_thread_id, NULL, thread_handler_UI , NULL) != 0)
    {
        perror("Not able to create UI-thread");
        exit(-1);
    }

    // Server waits for connections
    while(1)
    {
        printf("(Server) %d Ready to accept connections\n", getpid());

        client_fd = accept(sock_fd,(struct sockaddr*)&app_client_addr,&size_addr);
        if(client_fd == -1) {
			perror("accept");
			exit(-1);
		}

        printf("accepted one more client -> socket %d from path %s\n",client_fd, app_client_addr.sun_path);

        pt = pthread_create(&thread_id, NULL , handle_request, &client_fd);
        // Verify if thread creation when ok
        if (pt != 0){
            perror("Not able to create thread");
			exit(-1);
        }
    }

    

    exit(EXIT_FAILURE);
}
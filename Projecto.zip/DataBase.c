#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <time.h>
#include <fcntl.h>
#include <unistd.h>
#include <pthread.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/types.h>

#include "DataBase.h"

typedef struct _data data;
struct _data
{
    char *key;
    char *value;
    data *next;
    data *prev;
};

typedef struct _groupList group;
struct _groupList
{
    char *group_id;
    data *data;
    group *next;
    group *prev;
};

group* data_base = NULL;

data* data_new_node(char *key, char *value)
{
    data* new = (data*) malloc(sizeof(data));
    if (new == NULL)
    {
        return NULL;
    }

    new->key = (char*) malloc(sizeof(char) * (strlen(key) + 1));
    if (new->key == NULL)
    {
        free(new);
        return NULL;
    }

    strcpy(new->key,key);

    new->value = (char*) malloc(sizeof(char) * (strlen(value) + 1));
    if (new->value == NULL)
    {
        free(new->key);
        free(new);
        return NULL;
    }

    strcpy(new->value,value);

    new->next = NULL;
    new->prev = NULL;

    return new;
}

int data_insert(char *key, char *value, data** head_ptr)
{
    if(*head_ptr == NULL)
    {
        *head_ptr = data_new_node(key,value);
        if(*head_ptr == NULL)
        {
            return -1;
        }

        return 0;
    }

    data* tmp = data_new_node(key,value);
    if(tmp == NULL)
    {
        return -2;
    }

    tmp->next = *head_ptr;
    (*head_ptr)->prev = tmp;
    *head_ptr = tmp;

    return 0;
}

data* data_find(char *key, data *head)
{
    if(key == NULL)
    {
        return NULL;
    }

    data *tmp = head;

    while (tmp != NULL)
    {
        if (strcmp(key, tmp->key) == 0)
        {
            break;
        }

        tmp = tmp->next;
    }

    return tmp;
}

char* data_get(char *key, data *head)
{

    data *tmp = data_find(key,head);
    if(tmp == NULL)
    {
        return NULL;
    }

    return tmp->value;
}

void data_free(data *node)
{
    free(node->key);
    free(node->value);
    node->next = NULL;
    node->prev = NULL;
    free(node);
}

int data_remove(char *key, data **head_ptr)
{
    data *tmp = data_find(key,*head_ptr);

    if(tmp == NULL)
    {
        return -1;// Element not found
    }

    if (tmp == *head_ptr)
    {
        *head_ptr = tmp->next;
        data_free(tmp);
        return 0;
    }

    tmp->prev->next = tmp->next;

    if (tmp->next == NULL)
    {
        data_free(tmp);
        return 0;
    }

    tmp->next->prev = tmp->prev;
    
    data_free(tmp);
    
    return 0;
}

void data_delete(data *head)
{
    data* tmp = head;
    data* temp = tmp;

    while(tmp != NULL)
    {
        temp = temp->next;
        data_free(tmp);
        tmp = temp;
    }   
}

void data_printList(data* head)
{
    data* tmp = head;

    if(tmp == NULL)
    {
        printf("\t Empty\n");
        return;
    }

    while (tmp != NULL)
    {
        printf("\t %s %s\n", tmp->key, tmp->value);

        tmp = tmp->next;
    }   
}

int data_count(data* head)
{
    if(head == NULL)
    {
        return 0;
    }

    data* tmp = head;
    int count = 0;

    while (tmp != NULL)
    {
        count++;
        tmp = tmp->next;
    }

    return count;
    
}
/////////////////////////////////////////////////////
group* group_new_node(char* group_id)
{
    group* new = (group*) malloc(sizeof(group));
    if (new == NULL)
    {
        return NULL;
    }

    new->group_id = (char*) malloc(sizeof(char) * (strlen(group_id) + 1));
    if (new->group_id == NULL)
    {
        free(new);
        return NULL;
    }

    strcpy(new->group_id, group_id);

    new->data = NULL;

    new->next = NULL;
    new->prev = NULL;

    return new;
}

int group_insert(char *group_id, group **head_ptr)
{
    if (*head_ptr == NULL)
    {
        *head_ptr = group_new_node(group_id);
        if (*head_ptr == NULL)
        {
            return -1;
        }

        return 0;
    }

    group *tmp = group_new_node(group_id);
    if (tmp == NULL)
    {
        return -2;
    }

    tmp->next = *head_ptr;
    (*head_ptr)->prev = tmp;
    *head_ptr = tmp;

    return 0;
}

group* group_find(char* group_id, group* head)
{
    group *tmp = head;

    if(group_id == NULL)
    {
        return NULL;
    }

    while (tmp != NULL)
    {
        if (strcmp(group_id, tmp->group_id) == 0)
        {
            break;
        }

        tmp = tmp->next;
    }

    return tmp;
}

data** group_get_data(char* group_id, group* head)
{
    group *tmp = group_find(group_id, head);
    if (tmp == NULL)
    {
        return NULL;
    }

    return &tmp->data;
}

void group_free(group* node)
{
    free(node->group_id);
    data_delete(node->data);
    node->next = NULL;
    node->prev = NULL;
    free(node);
}

int group_remove(char *group_id, group **head_ptr)
{   
    if(group_id == NULL)
    {
        return -1;
    }

    group *tmp = group_find(group_id, *head_ptr);

    if (tmp == NULL)
    {
        return -2; // Element not found
    }

    if (tmp == *head_ptr)
    {
        *head_ptr = tmp->next;
        group_free(tmp);
        return 0;
    }

    tmp->prev->next = tmp->next;

    if (tmp->next == NULL)
    {
        group_free(tmp);
        return 0;
    }

    tmp->next->prev = tmp->prev;

    group_free(tmp);

    return 0;
}

void group_delete(group **head)
{
    group *tmp = *head;
    group *temp = tmp;

    while (tmp != NULL)
    {
        temp = temp->next;
        group_free(tmp);
        tmp = temp;
    }

    *head = NULL;
}

//////////////////////////////////////////////////////////////

int insert_in_data_base(char *group_id, char *key , char *value)
{   
    group* tmp = group_find(group_id,data_base);

    if(tmp == NULL)
    {
        if (group_insert(group_id, &data_base) != 0)
        {
            return -1;
        }

        if(key != NULL && value != NULL)
        {
            if (data_insert(key, value, group_get_data(group_id, data_base)) != 0)
            {
                return -2;
            }
        }

        return 0;
    }

    if(key == NULL || value == NULL)
    {
        return -3;
    }

    // Looks if the given key already existes
    data *temp = data_find(key, tmp->data);
    if(temp != NULL)
    {
        free(temp->value);
        temp->value = (char*) malloc(sizeof(char) * (strlen(value) + 1));
        if (temp->value == NULL)
        {
            return -4;
        }

        strcpy(temp->value,value);

        return 0;
    }

    // inserts the data in case the key is not founded
    if (data_insert(key, value, &(tmp->data)) != 0)
    {
        return -5;
    }

    return 0;
}

char* get_in_data_base(char *group_id, char *key){
    
    group* tmp = group_find(group_id,data_base);

    if(tmp == NULL)
        return NULL;

    return data_get(key, tmp->data);
}

int remove_from_data_base(char* group_id, char *key)
{
    group* tmp = group_find(group_id,data_base);

    if(tmp == NULL)
        return -1;
    
    if (data_remove(key, &(tmp->data)) != 0)
    {
        return -2;
    }

    return 0;
}

int delete_data_base()
{
    group_delete(&data_base);
    
    return 0;
}

void print_data_base()
{
    group *tmp = data_base;

    if(tmp == NULL)
    {
        printf("Empty\n");
    }

    while (tmp != NULL)
    {
        printf("%s\n", tmp->group_id);
        data_printList(tmp->data);
        tmp = tmp->next;
    }
}

int exists_in_data_base(char *group_id, char *key, char *value)
{
    if(data_base == NULL)
    {
        return 0; // group doesn't exists
    }

    data** tmp = group_get_data(group_id,data_base);
    if(tmp == NULL)
    {
        return 0; // group doesn't exists
    }

    char* str = data_get(key,*tmp);
    if(str == NULL)
    {
        return 0; // group doesn't exists
    }

    if(strcmp(value,str) != 0)
    {
        return 1;
    }

    return 2;

}

int remove_group_from_data_base(char *group_id)
{
    return group_remove(group_id,&data_base);
}

int group_size_from_data_base(char* group_id)
{   
    group* tmp = group_find(group_id,data_base);

    if(tmp == NULL)
    {
        return 0;
    }

    return data_count(tmp->data);
}
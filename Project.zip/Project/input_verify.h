#ifndef INPUT_VERIFY_H_
#define INPUT_VERIFY_H_

void print_usage();

int verify(char *command);

#endif // INPUT_VERIFY_H_

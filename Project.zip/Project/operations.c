#include "operations.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>

#include "utils.h"

#define KEY_MAX 32
#define MAX_BUFFER_SIZE 129 // 128+1
#define MAX_FND_REQUESTS 100

typedef struct _request_info
{
    int key;
    int n_id;
    char ip[MAX_BUFFER_SIZE];
    char port[MAX_BUFFER_SIZE];
}request_info;


char *sucessor_ip = NULL;
char *sucessor_port = NULL;
int sucessor_key=-1;

char *predecessor_ip = NULL;
char *predecessor_port = NULL;
int predecessor_key = -1;

char *self_ip = NULL;
char *self_port = NULL;
int self_key=-1;

char *shortcut_ip = NULL;
char *shortcut_port = NULL;
int shortcut_key = -1;

// Creates array of pending find requests
request_info request_buffer[MAX_FND_REQUESTS];

// State codification to handle udp comunications
enum udp_server_states{idle,waiting_ack};
int state = idle;

int n_id = 0;

// verifies if a key is valid
int check_key(int key)
{
    if(key < 0)
        return -1;
    
    if(key >= KEY_MAX)
        return -1;
    
    return 0;
}

// Receives a UDP message
void* ring_recvfrom(int socket_fd, char* buffer, int buffer_size, int* time_out)
{    
    // Validates time_out
    if(*time_out > 1 || *time_out < 0) return NULL;

    struct sockaddr *addr=NULL;
    addr = (struct sockaddr*) malloc(sizeof(struct sockaddr));
    if(addr==NULL) return NULL;

    // In case it receives a time_out  and was waiting a ACK
    if(*time_out==1 && state==waiting_ack)
    {   
        state = idle;
        *time_out = 0;
        sprintf(buffer,"IGNORE");
        printf("\ttime out\n");
        return addr;
    }

    // Validates arguments
    if(socket_fd<0 || buffer==NULL || buffer_size <= 0)
    {
        fprintf(stderr,"ring_recvfrom: %s\n",strerror(EINVAL));
        return NULL;
    }

    socklen_t addrlen;
    ssize_t n = 0;
    char ack[] = "ACK";

    addrlen=sizeof(*addr);

    n=recvfrom(socket_fd,buffer,buffer_size,0,addr,&addrlen);
    if(n==-1) return NULL;

    if(n<buffer_size) buffer[n] = '\0';

    // If it receives an ACK
    if(strstr(buffer,ack)!=NULL)
    {   
        // If the state is waiting_ack it changes it to idle
        // If the state is idles it consideres that it was a bad actor
        state=idle;
        return addr;
    }

    // If it receives another request and it is in waiting ACK state
    if(strstr(buffer,ack)==NULL && state==waiting_ack)
    {
        // It Ignores the request
        sprintf(buffer,"IGNORE");
        return addr;
    }

    // Sends an ack
    n=sendto(socket_fd,ack,3,0,addr,addrlen);
	if(n==-1) return NULL;

    return addr;
}

// Sends a UDP message
int ring_sendto(int socket_fd, char* msg, char* ip, char* port)
{
    // If it is waiting for a ACK it ignores other requests
    if(state==waiting_ack) return 1;

    // Validates arguments
    if(socket_fd<0 || msg==NULL || (ip==NULL && port==NULL))
    {
        fprintf(stderr,"ring_sendto: %s\n",strerror(EINVAL));
        return -1;
    }

    struct addrinfo hints,*res;
    int errcode;

    ssize_t n = 0;
    char buffer[MAX_BUFFER_SIZE];

    // Inicializations
    memset(buffer,0,MAX_BUFFER_SIZE);
    memset(&hints,0,sizeof hints);

    errcode=getaddrinfo(ip,port,&hints,&res);
    if(errcode!=0) return -1;

    n=sendto(socket_fd,msg,strlen(msg),0,res->ai_addr,res->ai_addrlen);
	if(n==-1) return -1;

    // Changes the comunication state
    state=waiting_ack;

    free(res);

    return 0;
}

// Prints current state from the node
void show_state(void)
{   
    if(self_ip != NULL)
    {   
        printf("predecessor: %d %s %s\n",predecessor_key,predecessor_ip,predecessor_port);

        printf("node: %d %s %s\n",self_key,self_ip,self_port);

        printf("sucessor: %d %s %s\n",sucessor_key,sucessor_ip,sucessor_port);
    }
    else printf("Node not created yet!\n");

    if(shortcut_key!=-1)
    {
        printf("shortcut: %d %s %s\n",shortcut_key,shortcut_ip,shortcut_port);
    }
    else printf("No shortcut yet!\n");
}

// Creates the ring with one node
int set_new(int *server_fd,int *client_fd, int *udp_fd, int key, char* ip, char* port, int backlog)
{      
    // Validates input
    if(server_fd == NULL || client_fd == NULL || (ip == NULL && port == NULL) || backlog <= 0)
    {
        fprintf(stderr,"set_new: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was already created
    if(!(self_ip == NULL && self_port == NULL)) return -1;

    // Inicializes the values incide
    memset(request_buffer,0,sizeof(request_info) * MAX_FND_REQUESTS);

    // Inicializes udp server state
    state = idle;

    // Creates the tcp socket for comunication
    *client_fd = setup_tcp_client();
    if(*client_fd == -1)
    {
        fprintf(stderr,"set_new: %s\n",strerror(EINVAL));
        return -1;
    }

    // Creates the tcp socket for waiting connections
    *server_fd = setup_tcp_server(ip,port,backlog);
    if(*server_fd == -1)
    {
        fprintf(stderr,"set_new: %s\n",strerror(EINVAL));
        return -1;
    }

    // Creates the udp socket to comunication
    *udp_fd = setup_udp_server(ip,port);
    if(*udp_fd == -1)
    {
        fprintf(stderr,"set_new: %s\n",strerror(EINVAL));
        return -1;
    }

    // Allocates memory to save its sucessor ip address
    sucessor_ip = (char*) malloc(sizeof(char) * MAX_BUFFER_SIZE);
    if (sucessor_ip == NULL)
    {
        perror("set_new");
        return -1;
    }
    // Allocates memory to save its sucessor port
    sucessor_port = (char*) malloc(sizeof(char) * MAX_BUFFER_SIZE);
    if(sucessor_port == NULL)
    {
        perror("set_new");
        return -1;
    }

    // Allocates memory to save its self ip address
    self_ip = (char*) malloc(sizeof(char) * MAX_BUFFER_SIZE);
    if (self_ip == NULL)
    {
        perror("set_new");
        return -1;
    }
    // Allocates memory to save its self port
    self_port = (char*) malloc(sizeof(char) * MAX_BUFFER_SIZE);
    if(self_port == NULL)
    {
        perror("set_new");
        return -1;
    }

    // Allocates memory to save its predecessor ip address
    predecessor_ip = (char*) malloc(sizeof(char) * MAX_BUFFER_SIZE);
    if (predecessor_ip == NULL)
    {
        perror("set_new");
        return -1;
    }
    // Allocates memory to save its predecessor port
    predecessor_port = (char*) malloc(sizeof(char) * (128+1));
    if(predecessor_port == NULL)
    {
        perror("set_new");
        return -1;
    }

    // inicialiazes strings
    memset(sucessor_ip,0,MAX_BUFFER_SIZE);
    memset(sucessor_port,0,MAX_BUFFER_SIZE);
    memset(self_ip,0,MAX_BUFFER_SIZE);
    memset(self_port,0,MAX_BUFFER_SIZE);
    memset(predecessor_ip,0,MAX_BUFFER_SIZE);
    memset(predecessor_port,0,MAX_BUFFER_SIZE);

    // Sets single node ring
    strcpy(sucessor_ip,ip);
    strcpy(self_ip,ip);
    strcpy(predecessor_ip,ip);

    strcpy(sucessor_port,port);
    strcpy(self_port,port);
    strcpy(predecessor_port,port);

    self_key = key;
    sucessor_key = key;
    predecessor_key = key;
    
    return 0;
}

// Free all used resources
void free_resource(void)
{
    // Free if it cans
    if (self_ip!=NULL) free(self_ip);
    self_ip = NULL;
    if (self_port!=NULL) free(self_port);
    self_port = NULL;
    if (predecessor_ip!=NULL) free(predecessor_ip);
    predecessor_ip = NULL;
    if (predecessor_port!=NULL) free(predecessor_port);
    predecessor_port = NULL;
    if (sucessor_ip!=NULL) free(sucessor_ip);
    sucessor_ip = NULL;
    if (sucessor_port!=NULL) free(sucessor_port);
    sucessor_port = NULL;
}

// Leaves if still in the ring and frees the server resources
int leave_and_exit(int server_client_fd)
{   
    // Validates arguments
    if(server_client_fd < 0) return -1;

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    // If the node is in a ring
    if(strcmp(self_ip,sucessor_ip)!=0 || strcmp(self_port,sucessor_port)!=0 ||
    strcmp(self_ip,predecessor_ip)!=0 || strcmp(self_port,predecessor_port)!=0)
    {   
        if(request_leave(server_client_fd)!=0) return -1;
    }

    free_resource();

    return 0;
}

// Creates a shortcute for the node | chord | UDP
int set_shortcut(int key, char* ip, char* port)
{   
    // Validates arguments
    if(check_key(key)!=0 || (ip==NULL && port==NULL))
    {
        fprintf(stderr,"set_shortcut: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    // Allocates memory to save its shortcut ip address
    shortcut_ip = (char*) malloc(sizeof(char) * (128+1));
    if (shortcut_ip == NULL)
    {
        perror("set_shortcut");
        return -1;
    }

    // Allocates memory to save its shortcut port
    shortcut_port = (char*) malloc(sizeof(char) * (128+1));
    if(shortcut_port == NULL)
    {
        perror("set_shortcut");
        return -1;
    }

    memset(shortcut_ip,0,MAX_BUFFER_SIZE);
    memset(shortcut_port,0,MAX_BUFFER_SIZE);

    strcpy(shortcut_ip,ip);
    strcpy(shortcut_port,port);
    shortcut_key = key;

    return 0;
}

// Removes a shortcut for the node | echord | UPD
int remove_shortcut(void)
{   
    // Validates arguments
    if(check_key(shortcut_key)==-1 && shortcut_ip==NULL && shortcut_port==NULL)
    {
        fprintf(stderr,"set_shortcut: Theres no shortcut address to remove\n");
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    free(shortcut_ip);
    free(shortcut_port);
    shortcut_key=-1;

    return 0;
}

// Entry of the node in the ring knowing that is predecessor ip address
int request_pentry(int server_client_fd, int key, char* ip, char* port)
{   
    // Validates atguments
    if(server_client_fd <0 || (ip == NULL && port == NULL))
    {
        fprintf(stderr,"request_self: %s\n",strerror(EINVAL));
        return -1;
    }

    // Caso a chave for inválida
    if(check_key(key)!=0)
    {
        fprintf(stderr,"request_self: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    // If the node is already in a ring
    if(strcmp(self_ip,sucessor_ip)!=0 || strcmp(self_port,sucessor_port)!=0 ||
    strcmp(self_ip,predecessor_ip)!=0 || strcmp(self_port,predecessor_port)!=0)
    {   
        fprintf(stderr,"request_self: %s\n",strerror(EINVAL));
        return -1;
    }

    // So that it can´t send pentry to itself
    if(strcmp(self_ip,ip)==0 && strcmp(self_port,port)==0) return -1;

    int comunication_tunnel=-1;
    char buffer[MAX_BUFFER_SIZE];

    memset(buffer,0,MAX_BUFFER_SIZE);

    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,ip,port);
    if(comunication_tunnel!=0) return -1;

    sprintf(buffer,"SELF %d %s %s\n",self_key,self_ip,self_port);

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    strcpy(predecessor_ip,ip);
    strcpy(predecessor_port,port);
    predecessor_key = key;

    return 0;
}

// Leaving of a node from a ring knowing that. Sends a PRED request
int request_leave(int server_client_fd)
{
    // Validates arguments
    if(server_client_fd < 0) return -1;
    
    // verifies if node is a single ring
    if(strcmp(self_ip,sucessor_ip)==0 && strcmp(self_port,sucessor_port)==0 &&
    strcmp(self_ip,predecessor_ip)==0 && strcmp(self_port,predecessor_port)==0) return -1;

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    int comunication_tunnel=-1;
    char buffer[MAX_BUFFER_SIZE];

    memset(buffer,0,MAX_BUFFER_SIZE);
    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
    if(comunication_tunnel!=0)
    {
        perror("request_leave");
        return -1;
    }

    sprintf(buffer,"PRED %d %s %s\n",predecessor_key,predecessor_ip,predecessor_port);

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    // Makes the node a it single element ring again
    memset(predecessor_ip,0,MAX_BUFFER_SIZE);
    memset(predecessor_port,0,MAX_BUFFER_SIZE);

    strcpy(predecessor_ip,self_ip);
    strcpy(predecessor_port,self_port);
    predecessor_key = self_key;

    memset(sucessor_ip,0,MAX_BUFFER_SIZE);
    memset(sucessor_port,0,MAX_BUFFER_SIZE);

    strcpy(sucessor_ip,self_ip);
    strcpy(sucessor_port,self_port);
    sucessor_key = self_key;

    return 0;
}

// Mesures the distance of node A to B 
int distance(int A, int B)
{   
    return (A<=B) ? (B-A) % KEY_MAX : KEY_MAX - (A-B) % KEY_MAX;
}

// Makes a find request to the ring
int request_find(int server_client_fd,int udp_server_fd, int search_key)
{   
    // Input validation
    if(server_client_fd<0 || udp_server_fd<0 || search_key<0)
    {
        fprintf(stderr,"request_find: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    char buffer[MAX_BUFFER_SIZE];
    int comunication_tunnel = 0;
    int n = -1;

    memset(buffer,0,MAX_BUFFER_SIZE);

    // Verifies if the key belongs to it
    if(distance(self_key,search_key) < distance(sucessor_key,search_key))
    {   
        if(strlen(request_buffer[n_id].ip) > 0)
        {
            sprintf(buffer,"EPRED %d %s %s",self_key,self_ip,self_port);

            // Sends msg
            if((n=ring_sendto(udp_server_fd,buffer,request_buffer[n_id].ip,request_buffer[n_id].port))<0) return -1;

            if(n==0) printf("[udp] sent: %s\n",buffer);
            
            if(n==1) printf("[udp] still waiting ACK\n");

            n_id++;
            if(n_id>99) n_id=0;

            return 0;
        }

        printf("Key %d: node %d (%s:%s)\n",search_key,self_key,self_ip,self_port);
        return 0;
    }

    // Verifies if the key belongs to it's predecessor
    if(distance(predecessor_key,search_key) < distance(self_key,search_key))
    {   
        if(strlen(request_buffer[n_id].ip) > 0)
        {
            sprintf(buffer,"EPRED %d %s %s",predecessor_key,predecessor_ip,predecessor_port);

            // Sends msg
            if((n=ring_sendto(udp_server_fd,buffer,request_buffer[n_id].ip,request_buffer[n_id].port))<0) return -1;

            if(n==0) printf("[udp] sent: %s\n",buffer);
            
            if(n==1) printf("[udp] still waiting ACK\n");

            n_id++;
            if(n_id>99) n_id=0;

            return 0;
        }

        printf("Key %d: node %d (%s:%s)\n",search_key,predecessor_key,predecessor_ip,predecessor_port);
        return 0;
    }

    // Verifies if the key is equal to it's sucessor
    if(sucessor_key==search_key)
    {   
        if(strlen(request_buffer[n_id].ip) > 0)
        {
            sprintf(buffer,"EPRED %d %s %s",sucessor_key,sucessor_ip,sucessor_port);

            // Sends msg
            if((n=ring_sendto(udp_server_fd,buffer,request_buffer[n_id].ip,request_buffer[n_id].port))<0) return -1;

            if(n==0) printf("[udp] sent: %s\n",buffer);
            
            if(n==1) printf("[udp] still waiting ACK\n");

            n_id++;
            if(n_id>99) n_id=0;

            return 0;
        }

        printf("Key %d: node %d (%s:%s)\n",search_key,sucessor_key,sucessor_ip,sucessor_port);
        return 0;
    }

    // Sets the new id if it doen't have one
    if(strlen(request_buffer[n_id].ip)==0)
    {   
        if(n_id == 100) n_id=0;

        request_buffer[n_id].n_id = n_id;

        request_buffer[n_id].key = search_key;
    }

    sprintf(buffer,"FND %d %d %d %s %s",search_key,n_id,self_key,self_ip,self_port);

    ++n_id;

    // Decides to how sends the FND request
    if(shortcut_key>=0 && distance(shortcut_key,search_key) < distance(sucessor_key,search_key))
    {
        // Sends msg
        if((n=ring_sendto(udp_server_fd,buffer,shortcut_ip,shortcut_port))<0) return -1;

        if(n==0) printf("[udp] sent: %s\n",buffer);
            
        if(n==1) printf("[udp] still waiting ACK\n");

        return 0;
    }

    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
    if(comunication_tunnel!=0)
    {
        perror("request_find");
        return -1;
    }

    // Adds the needed '/n' for TCP communication
    buffer[strlen(buffer)] = '\n';

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    return 0;
}

// Entry of a node that doen't know is predecessor
int request_bentry(int server_client_fd,int udp_server_fd, int key, char* ip, char* port)
{
    // Validates arguments
    if(server_client_fd < 0 || udp_server_fd < 0 || check_key(key)!=0 || (ip==NULL && port==NULL)) return -1;

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    char buffer[MAX_BUFFER_SIZE];
    int n = -1;
    
    // Inicializes resources
    memset(buffer,0,MAX_BUFFER_SIZE);

    sprintf(buffer,"EFND %d",self_key);

    // Sends msg
    if((n=ring_sendto(udp_server_fd,buffer,ip,port))<0) return -1;

    if(n==0) printf("[udp] sent: %s\n",buffer);
            
    if(n==1) printf("[udp] still waiting ACK\n");

    return 0;
}

// Handles UDP received msg
int udp_msg_handler(int server_client_fd,int udp_server_fd, void *addr, char* msg)
{   
    // Validates arguments
    if(server_client_fd <0 || msg==NULL || udp_server_fd <0)
    {
        fprintf(stderr,"udp_msg_handler: %s\n",strerror(EINVAL));
        return -1;
    }

    char ip[MAX_BUFFER_SIZE], port[MAX_BUFFER_SIZE];
    int key=0, n=0, k=0;
    
    // Inicialization
    memset(ip,0,MAX_BUFFER_SIZE);
    memset(port,0,MAX_BUFFER_SIZE);

    if(strstr(msg,"EFND ")!=NULL)
    {   
        sscanf(msg,"EFND %d",&key);
        if(handle_EFND(udp_server_fd,server_client_fd,addr,key)!=0) return -1;
    }
    else if(strstr(msg,"FND ")!=NULL)
    {   
        sscanf(msg,"FND %d %d %d %s %s",&k,&n,&key,ip,port);
        if(handle_FND(server_client_fd,udp_server_fd,k,n,key,ip,port)!=0) return -1;
        
    }
    else if(strstr(msg,"RSP ")!=NULL)
    {   
        sscanf(msg,"RSP %d %d %d %s %s",&k,&n,&key,ip,port);
        if(handle_RSP(server_client_fd,udp_server_fd,k,n,key,ip,port)!=0) return -1;
        
    }
    else if(strstr(msg,"EPRED ")!=NULL)
    {   
        sscanf(msg,"EPRED %d %s %s",&key,ip,port);
        if(handle_EPRED(server_client_fd,key,ip,port)) return -1;
    }
    else if(strstr(msg,"ACK")!=NULL || strstr(msg,"IGNORE")!=NULL)
    {
        return 0;
    }
    else return -1;

    return 0;

}

// Handles TCP received msg
int tcp_msg_handler(int server_client_fd, int udp_server_fd, char* msg)
{   
    // Validates arguments
    if(server_client_fd <0 || msg==NULL || udp_server_fd <0)
    {
        fprintf(stderr,"tcp_msg_handler: %s\n",strerror(EINVAL));
        return -1;
    }

    char ip[MAX_BUFFER_SIZE], port[MAX_BUFFER_SIZE];
    int key=0, n=0, k=0;
    
    // Inicialization
    memset(ip,0,MAX_BUFFER_SIZE);
    memset(port,0,MAX_BUFFER_SIZE);
    
    if(strstr(msg,"SELF ")!=NULL)
    {
        sscanf(msg,"SELF %d %s %s\n",&key,ip,port);
        if(handle_SELF(server_client_fd,key,ip,port)!=0) return -1;
    }
    else if(strstr(msg,"PRED ")!=NULL)
    {   
        sscanf(msg,"PRED %d %s %s\n",&key,ip,port);
        if(handle_PRED(server_client_fd,key,ip,port)!=0) return -1;
    }
    else if(strstr(msg,"FND ")!=NULL)
    {
        sscanf(msg,"FND %d %d %d %s %s\n",&k,&n,&key,ip,port);
        if(handle_FND(server_client_fd,udp_server_fd,k,n,key,ip,port)!=0) return -1;
    }
    else if(strstr(msg,"RSP ")!=NULL)
    {
        sscanf(msg,"RSP %d %d %d %s %s\n",&k,&n,&key,ip,port);
        if(handle_RSP(server_client_fd,udp_server_fd,k,n,key,ip,port)!=0) return -1;
    }
    else return -1;

    return 0;
}

// Handles a SELF request from another node
int handle_SELF(int server_client_fd, int key, char* ip, char* port)
{
    // Validates input
    if(server_client_fd <0 || (ip == NULL && port == NULL) || check_key(key)!=0)
    {
        fprintf(stderr,"handle_SELF: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    // If the node is entering in a ring
    if(strcmp(self_ip,predecessor_ip)!=0 && strcmp(self_port,predecessor_port)!=0 && 
    strcmp(self_ip,sucessor_ip)==0 && strcmp(self_port,sucessor_port)==0)
    {
        strcpy(sucessor_ip,ip);
        strcpy(sucessor_port,port);
        sucessor_key = key;

        return 0;
    }

    int comunication_tunnel=-1;
    char buffer[MAX_BUFFER_SIZE];
    memset(buffer,0,MAX_BUFFER_SIZE);

    // If the node is single in a ring
    if(strcmp(predecessor_ip,sucessor_ip)==0 && strcmp(predecessor_port,sucessor_port)==0
    && strcmp(self_ip,sucessor_ip)==0 && strcmp(self_port,sucessor_port)==0)
    {  
        // Sets new sucessor
        strcpy(sucessor_ip,ip);
        strcpy(sucessor_port,port);
        sucessor_key = key;

        // Sets new predecessor
        strcpy(predecessor_ip,ip);
        strcpy(predecessor_port,port);
        predecessor_key = key;

        sprintf(buffer,"SELF %d %s %s\n",self_key,self_ip,self_port);

        // Stablishes connection
        comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
        if(comunication_tunnel!=0) return -1;

        // Sends msg
        if(write_all(server_client_fd,buffer)!=0) return -1;

        printf("[tcp] sent: %s",buffer);

        return 0;
    }

    // In case the sucessor leaves the ring
    if(distance(self_key,key) > distance(self_key,sucessor_key))
    {   
        // Sets new sucessor
        memset(sucessor_ip,0,MAX_BUFFER_SIZE);
        memset(sucessor_port,0,MAX_BUFFER_SIZE);
        strcpy(sucessor_ip,ip);
        strcpy(sucessor_port,port);
        sucessor_key = key;

        return 0;
    }
    sprintf(buffer,"PRED %d %s %s\n",key,ip,port);

    // Stablishes connection
    comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
    if(comunication_tunnel!=0) return -1;

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    // Sets new sucessor
    memset(sucessor_ip,0,MAX_BUFFER_SIZE);
    memset(sucessor_port,0,MAX_BUFFER_SIZE);
    strcpy(sucessor_ip,ip);
    strcpy(sucessor_port,port);
    sucessor_key = key;

    return 0;
}

// Handles a PRED request from another
int handle_PRED(int server_client_fd, int key, char* ip, char* port)
{   
    // Validates input
    if(server_client_fd <0 || (ip == NULL && port == NULL))
    {
        fprintf(stderr,"handle_PRED: %s\n",strerror(EINVAL));
        return -1;
    }
    
    // Caso a chave for inválida
    if(check_key(key)!=0)
    {
        fprintf(stderr,"handle_PRED: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node not created
    if(self_ip == NULL && self_port == NULL) return -1;


    // If the node is single in a ring
    if(strcmp(predecessor_ip,sucessor_ip)==0 && strcmp(predecessor_port,sucessor_port)==0
    && strcmp(self_ip,sucessor_ip)==0 && strcmp(self_port,sucessor_port)==0) return -1;


    // If node after this pred is going to became a single element ring
    if(strcmp(self_ip,ip)==0 && strcmp(self_port,port)==0)
    {   
        // Sets new predecessor
        memset(predecessor_ip,0,MAX_BUFFER_SIZE);
        memset(predecessor_port,0,MAX_BUFFER_SIZE);
        strcpy(predecessor_ip,self_ip);
        strcpy(predecessor_port,self_port);
        predecessor_key = key;

        // Sets new sucessor
        memset(sucessor_ip,0,MAX_BUFFER_SIZE);
        memset(sucessor_port,0,MAX_BUFFER_SIZE);
        strcpy(sucessor_ip,self_ip);
        strcpy(sucessor_port,self_port);
        sucessor_key = key;

        return 0;
    }

    int comunication_tunnel=-1;
    char buffer[MAX_BUFFER_SIZE];

    memset(buffer,0,MAX_BUFFER_SIZE);
    
    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,ip,port);
    if(comunication_tunnel!=0) return -1;
    
    sprintf(buffer,"SELF %d %s %s\n",self_key,self_ip,self_port);

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    memset(predecessor_ip,0,MAX_BUFFER_SIZE);
    memset(predecessor_port,0,MAX_BUFFER_SIZE);
    strcpy(predecessor_ip,ip);
    strcpy(predecessor_port,port);
    predecessor_key = key;

    return 0;
}

// Handles a FND request from another node
int handle_FND(int server_client_fd,int udp_server_fd,int search_key,
int n,int source_key,char* source_ip,char* source_port)
{
    // Input validation
    if(server_client_fd<0 || udp_server_fd<0 || check_key(search_key)!=0 || n < 0 || 
    n>99 || check_key(source_key) || (source_ip == NULL && source_port==NULL))
    {
        fprintf(stderr,"handle_FND: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    char buffer[MAX_BUFFER_SIZE];
    int comunication_tunnel = 0;
    int nn = -1;

    memset(buffer,0,MAX_BUFFER_SIZE);

    printf("%d %d %d %d\n",self_key,shortcut_key,sucessor_key,source_key);

    // Verifies if the key belongs to it and sends RSP request
    if(distance(self_key,search_key) < distance(sucessor_key,search_key))
    {   
        sprintf(buffer,"RSP %d %d %d %s %s",source_key,n,self_key,self_ip,self_port);
    }
    else sprintf(buffer,"FND %d %d %d %s %s",search_key,n,source_key,source_ip,source_port);

    // Decides who sends the FND request
    if(shortcut_key>=0 && distance(shortcut_key,source_key) < distance(sucessor_key,source_key))
    {
        // Sends msg
        if((nn=ring_sendto(udp_server_fd,buffer,shortcut_ip,shortcut_port))<0) return -1;
        
        printf("s=%d suc=%d\n",distance(shortcut_key,search_key), distance(sucessor_key,search_key));

        if(nn==0) printf("[udp] sent: %s\n",buffer);
            
        if(nn==1) printf("[udp] still waiting ACK\n");

        return 0;
    }

    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
    if(comunication_tunnel!=0)
    {
        perror("handle_FND");
        return -1;
    }
    // Adds the needed '/n' for TCP communication
    buffer[strlen(buffer)] = '\n';

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    return 0;
}

// Handles a RSP request from another node
int handle_RSP(int server_client_fd,int udp_server_fd,int query_source_key,
int n,int query_result_key,char* query_result_ip,char* query_result_port)
{
    // Input validation
    if(server_client_fd<0 || udp_server_fd<0 || check_key(query_source_key)!=0 || n < 0 || 
    n>99 || check_key(query_result_key) || (query_result_ip == NULL && query_result_port==NULL))
    {
        fprintf(stderr,"handle_RSP: %s\n",strerror(EINVAL));
        return -1;
    }

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;

    char buffer[MAX_BUFFER_SIZE];
    int comunication_tunnel = 0;
    int nn = -1;

    memset(buffer,0,MAX_BUFFER_SIZE);

    // Verifies if the find response belongs to it prints the information
    if(distance(self_key,query_source_key) < distance(sucessor_key,query_source_key))
    {   
        if(strlen(request_buffer[n].ip) > 0)
        {
            sprintf(buffer,"EPRED %d %s %s",query_result_key,query_result_ip,query_result_port);

            // Sends msg
            if((nn=ring_sendto(udp_server_fd,buffer,request_buffer[n].ip,request_buffer[n].port))<0) return -1;

            if(nn==0) printf("[udp] sent: %s\n",buffer);
            
            if(nn==1) printf("[udp] still waiting ACK\n");

            return 0;
        }

        printf("\nkey %d: node %d (%s:%s)\n",request_buffer[n].key,query_result_key,query_result_ip,query_result_port);
        return 0;
    }

    sprintf(buffer,"RSP %d %d %d %s %s",query_source_key,n,query_result_key,query_result_ip,query_result_port);

    // Decides to how sends the RSP request
    if(shortcut_key>=0 && distance(shortcut_key,query_source_key) < distance(sucessor_key,query_source_key))
    {
        // Sends msg
        if((nn=ring_sendto(udp_server_fd,buffer,shortcut_ip,shortcut_port))<0) return -1;
        
        if(nn==0) printf("[udp] sent: %s\n",buffer);
            
        if(nn==1) printf("[udp] still waiting ACK\n");

        return 0;
    }

    // Makes connection
    comunication_tunnel = tcp_connect(server_client_fd,sucessor_ip,sucessor_port);
    if(comunication_tunnel!=0)
    {
        perror("handle_RSP");
        return -1;
    }
    
    // Adds the needed '\n' for TCP communication
    buffer[strlen(buffer)] = '\n';

    // Sends msg
    if(write_all(server_client_fd,buffer)!=0) return -1;

    printf("[tcp] sent: %s",buffer);

    return 0;
}

// Handles a EFND request from another node
int handle_EFND(int udp_server_fd, int server_client_fd,void *addr, int key)
{
    // Validates arguments
    if(udp_server_fd < 0 || server_client_fd < 0 || check_key(key)!=0) return -1;

    // Verifies if the node was not created
    if(self_ip == NULL && self_port == NULL) return -1;
    
    char buffer[MAX_BUFFER_SIZE];

    memset(buffer,0,MAX_BUFFER_SIZE);

    request_buffer[n_id].key = key;
    request_buffer[n_id].n_id = n_id;
    if(addr_to_ipv4(addr,buffer)!=0) return -1;
     
    memset(request_buffer[n_id].ip,0,MAX_BUFFER_SIZE);
    memset(request_buffer[n_id].port,0,MAX_BUFFER_SIZE);

    sscanf(buffer,"%s %s",request_buffer[n_id].ip,request_buffer[n_id].port);

    // Requests a find
    if(request_find(server_client_fd,udp_server_fd,key)!=0) return -1;

    return 0;
}

// Handles a EPRED request from another node
int handle_EPRED(int server_client_fd, int key, char* ip, char* port)
{   
    // Validates arguments
    if(server_client_fd <0 || check_key(key)!=0 || (ip == NULL && port == NULL))
    {   
        fprintf(stderr,"handle_EPRED: %s\n",strerror(EINVAL));
        return -1;
    }

    // Requests a pentry
    if(request_pentry(server_client_fd,key,ip,port)!=0) return -1;

    return 0;
}
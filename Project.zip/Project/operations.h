#ifndef OPERATIONS_H_
#define OPERATION_H_

/*Não tem verificações das chaves como deve ser*/

// Receives a UDP message and return the address
void* ring_recvfrom(int socket_fd, char* msg, int buffer_size, int* time_out);

// Sends a UDP message
int ring_sendto(int socket_fd, char* msg, char* ip, char* port);

// Prints current state from the node
void show_state(void);

// Creates the ring with one node | TCP
int set_new(int *server_fd,int *client_fd, int *udp_fd, int key, char* ip, char* port, int backlog);

// Free all resources
void free_resource(void);

// Leaves if still in the ring and frees the server resources
int leave_and_exit(int server_client_fd);

// Creates a shortcute for the node | chord | UDP
int set_shortcut(int key, char* ip, char* port);

// Removes a shortcut for the node | echord | UPD
int remove_shortcut(void);

// Entry of the node in the ring knowing that is predecessor ip address. Sends a SELF request
int request_pentry(int server_client_fd, int key, char* ip, char* port);

// Leaving of a node from a ring knowing that. Sends a PRED request
int request_leave(int server_client_fd);

// Makes a find request to the ring
int request_find(int server_client_fd,int udp_server_fd, int search_key);

// Entry of a node that doen't know is predecessor
int request_bentry(int server_client_fd,int udp_server_fd, int search_key, char* ip, char* port);

// Handles UDP received msg
int udp_msg_handler(int server_client_fd,int udp_server_fd, void* addr, char* msg);

// Handles TCP received msg
int tcp_msg_handler(int server_client_fd,int udp_server_fd,char* msg);

// Handles a SELF request from another node
int handle_SELF(int server_client_fd, int key, char* ip, char* port);

// Handles a PRED request from another node
int handle_PRED(int server_client_fd, int key, char* ip, char* port);

// Handles a FND request from another node
int handle_FND(int server_client_fd,int udp_server_fd,int search_key,
int n,int source_key,char* source_ip,char* source_port);

// Handles a RSP request from another node
int handle_RSP(int server_client_fd,int udp_server_fd,int finded_key,
int n,int destination_key,char* destination_ip,char* destination_port);

// Handles a EFND request from another node
int handle_EFND(int udp_server_fd, int server_client_fd, void* addr, int key);

// Handles a EPRED request from another node
int handle_EPRED(int server_client_fd, int key, char* ip, char* port);

#endif
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include "input_verify.h"

//this function prints the correct usage in case of invalid input
void print_usage(){
    printf("Command Usage:\n\n");
    printf("• new or n\n");
    printf("• bentry boot boot.IP boot.port or b boot boot.IP boot.port\n");
    printf("• pentry pred pred.IP pred.port or p pred pred.IP pred.port\n");
    printf("• chord i i.IP i.port or c i i.IP i.port\n");
    printf("• dchord or d\n");
    printf("• show or s\n");
    printf("• find k or f k\n");
    printf("• leave or l\n");
    printf("• exit or e\n");
    printf("• help or h\n\n");
}

//function to verify if the user inputs are valid
int verify(char *command){
    int a;
    char word[5][30];
    int z;
    a = sscanf(command,"%s %s %s %s %s",word[0],word[1],word[2],word[3],word[4]);
    if (a == 1){
        if ((strcmp(word[0],"new") != 0) && (strcmp(word[0],"dchord") != 0) && (strcmp(word[0],"show") != 0) && (strcmp(word[0],"leave") != 0) && (strcmp(word[0],"exit") != 0) && (strcmp(word[0],"help") != 0)
        && (strcmp(word[0],"n") != 0) && (strcmp(word[0],"d") != 0) && (strcmp(word[0],"s") != 0) && (strcmp(word[0],"l") != 0) && (strcmp(word[0],"e") != 0) && (strcmp(word[0],"h") != 0)){
            return 0;
        }
    }else if (a == 2){
        int b;
        if (strcmp(word[0],"find") != 0 && strcmp(word[0],"f") != 0){
            return 0;
        }
        b = sscanf(word[1],"%d",&z);
        if (b == 0){
            return 0;
        }

    }else if (a == 4){
        if ((strcmp(word[0],"bentry") != 0) && (strcmp(word[0],"pentry") != 0) && (strcmp(word[0],"chord") != 0) && (strcmp(word[0],"b") != 0) && (strcmp(word[0],"p") != 0) && (strcmp(word[0],"c") != 0)){
            return 0;
        }
    }else{
        return 0;
    }

    if ((strcmp(word[0],"new") == 0) || (strcmp(word[0],"n") == 0)){
        return 1;
    }
    if ((strcmp(word[0],"bentry") == 0) || (strcmp(word[0],"b") == 0)){
        return 2;
    }
    if ((strcmp(word[0],"pentry") == 0) || (strcmp(word[0],"p") == 0)){
        return 3;
    }
    if ((strcmp(word[0],"chord") == 0) || (strcmp(word[0],"c") == 0)){
        return 4;
    }
    if ((strcmp(word[0],"dchord") == 0) || (strcmp(word[0],"d") == 0)){
        return 5;
    }
    if ((strcmp(word[0],"show") == 0) || (strcmp(word[0],"s") == 0)){
        return 6;
    }
    if ((strcmp(word[0],"find") == 0) || (strcmp(word[0],"f") == 0)){
        return 7;
    }
    if ((strcmp(word[0],"leave") == 0) || (strcmp(word[0],"l") == 0)){
        return 8;
    }
    if ((strcmp(word[0],"exit") == 0) || (strcmp(word[0],"e") == 0)){
        return 9;
    }
    if ((strcmp(word[0],"help") == 0) || (strcmp(word[0],"h") == 0)){
        return 10;
    }
    return 0;
}

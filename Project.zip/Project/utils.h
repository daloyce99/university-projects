#ifndef UTILS_H_
#define UTILS_H_

// Creates a TCP client and returns it's file descriptor
int setup_tcp_client(void);

// Trys to connect to a given address and port
int tcp_connect(int client_fd, char* ip, char* port);

// Creates a TCP server and returns it's file descriptor
int setup_tcp_server(char* ip,char* port,int backlog);

// Ensures that a TCP read gets all the bytes
int read_all(int socket_fd, char* buffer, int buffer_size);

// Ensures thst a TCP write sends all the bytes
int write_all(int socket_fd, char* msg);

// Clear addrinfo list of TCP server
void clear_tcp_server_addr(void);

// Creates a UDP client and returns it's file descriptor
int setup_udp_client(void);

// Creates a UDP server and returns it's file descriptor
int setup_udp_server(char* ip,char* port);

// Clear addrinfo list of UDP server
void clear_udp_server_addr(void);

// Print to buffer info from addr struct
int addr_to_ipv4(void* addr, char* buffer);

// Given a string with the format "ip:port" it gives the currespondent addr
void* ipv4_to_addr(char* ip_port);

#endif
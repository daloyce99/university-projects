#include "utils.h"

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <unistd.h>
#include <arpa/inet.h>

#define SOCK_ERROR -1

#define MAX_BUFFER_SIZE 129

// Trys to connect to a given address and port
int tcp_connect(int client_fd, char* ip, char* port)
{   
    // Verifies the input
    if(client_fd < 0 || (ip==NULL && port==NULL)) return -1;

    struct addrinfo hints,*res=NULL;
	int n=0;

    // Inicializations
    memset(&hints,0,sizeof hints);
    hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_STREAM;

    // Gets addr from target ip and port
    n=getaddrinfo(ip,port,&hints,&res);
	if(n!=0) return -1;
    
    // Connects to target ip address and port
	n = connect(client_fd,res->ai_addr,res->ai_addrlen);
	if(n==-1) return -1;

    free(res);

    return 0;
}

// Verifies any socket error and prints msg in stderr
int check(int exp, char* msg)
{
    if(exp == SOCK_ERROR)
    {
        perror(msg);
        exit(EXIT_FAILURE);
    }

    return exp;
}

// Creates a tcp client and returns it's file descriptor
int setup_tcp_client(void)
{
    int fd=-1;

    // Creates a TCP socket
    fd = check(socket(AF_INET,SOCK_STREAM,0),"setup_tcp_client");

    return fd;
}

// Creates a tcp server and returns it's file descriptor
int setup_tcp_server(char* ip,char* port,int backlog)
{   
    if ((ip == NULL && port == NULL) || backlog <=0)
    {   
        fprintf(stderr,"setup_tcp_server: %s\n", strerror(EINVAL));
        exit(EXIT_FAILURE);
    }
    
    struct addrinfo hints,*res=NULL;
    int server_fd=-1;

    // Inicializes
    memset(&hints,0,sizeof hints);

    // Configuring the address type we want the system to give us
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_STREAM;
    hints.ai_flags=AI_PASSIVE;

    // Creates a TCP socket
    server_fd = check(setup_tcp_client(),"setup_tcp_server");
    
    // Getting the address provided by the system in the port and ip resquested
    if(getaddrinfo(ip,port,&hints,&res)!=0)
    {
        perror("setup_tcp_server");
        exit(EXIT_FAILURE);
    }
    
    // Binding/Giving the provided address to our socket
    check(bind(server_fd,res->ai_addr,res->ai_addrlen),"setup_tcp_server");
    
    // Setting our socket in listening mode, so that it can wait for connections
    check(listen(server_fd,backlog),"setup_tcp_server");

    free(res);

    return server_fd;
}

// Ensures that a TCP read gets all the bytes
int read_all(int socket_fd, char* buffer, int buffer_size)
{   
    // Verifies inputs
    check(socket_fd,"read_all");

    if(buffer==NULL || buffer_size<=0)
    {
        fprintf(stderr,"read_all: %s\n",strerror(EINVAL));
        exit(EXIT_FAILURE);
    }

    ssize_t total_read=0,n_read=0;
    char *ptr=NULL;

    // Just in case it with trash
    memset(buffer,0,sizeof(char) * buffer_size);

    ptr=buffer;

    // Starts reading incoming bytes
    do
    {
        n_read= read(socket_fd,ptr,buffer_size);
        if(n_read==-1) return -1;
        
        if(n_read==0)break;//closed by peer
        
        total_read+=n_read;
        ptr+=n_read;
    }
    while(strstr(buffer,"\n")==NULL );
    
    // Puts a "\0" after "\n"
    buffer[total_read] = '\0';

    return 0;
}

// Ensures thst a TCP write sends all the bytes
int write_all(int socket_fd, char* msg)
{   
    // Verifies inputs
    check(socket_fd,"write_all");

    if(msg==NULL)
    {
        fprintf(stderr,"write_all: %s\n",strerror(EINVAL));
        exit(EXIT_FAILURE);
    }

    if(strstr(msg,"\n") == NULL)
    {
        fprintf(stderr,"write_all: %s\nMessage needs to end with '\\n'",strerror(EINVAL));
        exit(EXIT_FAILURE);
    }

    ssize_t nbytes=0,n_left=0,n_written=0;
	char *ptr,buffer[128+1];

    ptr=strcpy(buffer,msg);
	nbytes=strlen(msg);
	n_left=nbytes;

    // Starts writting
	while(n_left>0)
    {
		n_written=write(socket_fd,ptr,n_left);

		if(n_written<=0) return -1;

		n_left-=n_written;
		ptr+=n_written;
	}

    return 0;
}

// Creates a udp client and returns it's file descriptor
int setup_udp_client()
{
    int fd=-1;

    // Creates a UDP socket
    fd = check(socket(AF_INET,SOCK_DGRAM,0),"setup_udp_client");

    return fd;
}

// Creates a udp server and returns it's file descriptor
int setup_udp_server(char* ip,char* port)
{   
    if (ip == NULL || port == NULL)
    {   
        fprintf(stderr,"setup_udp_server: %s\n", strerror(EINVAL));
        exit(EXIT_FAILURE);
    }

    struct addrinfo hints,*res=NULL;
	int server_fd=-1;

    // Inicializes
    memset(&hints,0,sizeof hints);

    // Configuring the address type we want the system to give us
	hints.ai_family=AF_INET;
	hints.ai_socktype=SOCK_DGRAM;
	hints.ai_flags=AI_PASSIVE;

    // Creates UDP socket
    server_fd = check(setup_udp_client(),"setup_udp_server");

    // Getting the address provided by the system in the port and ip requested
    if(getaddrinfo(ip,port,&hints,&res)!=0)
    {
        perror("setup_udp_server");
        exit(EXIT_FAILURE);
    }

    // Binding/Giving the provided address to our socket
    check(bind(server_fd,res->ai_addr,res->ai_addrlen),"setup_udp_server");

    free(res);

    return server_fd;
}

// Prints info from sockaddr struct in string format to buffer
int addr_to_ipv4(void* addr, char* buffer)
{
    // Validates arguments
    if(addr==NULL || buffer==NULL) return -1;

    struct sockaddr_in *sin = (struct sockaddr_in *)addr;
    char *ip = NULL;
    uint16_t port;

    ip = inet_ntoa(sin->sin_addr);
    port = htons (sin->sin_port);

    if(sprintf(buffer,"%s %d", ip, port)<0) return -1;

    return 0;
}

// Given a string with the format "ip:port" it gives the currespondent addr
void* ipv4_to_addr(char* ip_port)
{   
    // Validates argument
    if(ip_port==NULL) return NULL;

    struct addrinfo hints,*res=NULL;
    int errcode=-1;

    char ip[MAX_BUFFER_SIZE], port[MAX_BUFFER_SIZE];

    memset(&hints,0,sizeof hints);
    memset(ip,0,MAX_BUFFER_SIZE);
    memset(port,0,MAX_BUFFER_SIZE);

    hints.ai_family=AF_INET;//IPv4
    hints.ai_socktype=SOCK_DGRAM;//UDP socket

    sscanf(ip_port,"%s:%s",ip,port);

    errcode=getaddrinfo(ip,port,&hints,&res);
    if(errcode!=0) return NULL;

    return res;
}
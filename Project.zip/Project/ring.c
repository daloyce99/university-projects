#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>

#include <netdb.h>
#include <unistd.h>

#include <signal.h>

#include "input_verify.h"
#include "utils.h"
#include "operations.h"

#define MAX_BUFFER_SIZE 129 // 128+1

int main(int argc, char** argv)
{   
    //verify if the program call is correct
    if (argc != 4){
        printf("Wrong Usage\nUsage: ring i i.IP i.port\n");
        exit(EXIT_FAILURE);
    }

    struct sigaction act;
    fd_set current_fd_set, ready_fd_set;
    int tcp_server_fd=-1,tcp_client_fd=-1;
    int udp_fd=-1;
    int client_fd=-1;

    char buffer[MAX_BUFFER_SIZE], command[101], ip[MAX_BUFFER_SIZE], port[MAX_BUFFER_SIZE];
    int key=-1;

    int ok = 1;
    int ex = 0;
    int timeOut = 0;
    int num_fd = 0;

    char dummy[MAX_BUFFER_SIZE];

    struct sockaddr addr, *udp_addr=NULL;
    socklen_t addrlen;

    struct timeval time_limit;

    // Inicializations
    memset(&act,0,sizeof act);
    act.sa_handler=SIG_IGN;
    memset(buffer,0,MAX_BUFFER_SIZE);
    memset(command,0,101);
    memset(dummy,0,MAX_BUFFER_SIZE);
    memset(ip,0,MAX_BUFFER_SIZE);
    memset(port,0,MAX_BUFFER_SIZE);
    memset(&time_limit,0,sizeof time_limit);

    key = atoi(argv[1]);
    strcpy(ip,argv[2]);
    strcpy(port,argv[3]);

    // Setting select time out to be 30 seconds
    time_limit.tv_sec = 10;

    // Prevents program to exit in case a connection is lost
    if(sigaction(SIGPIPE,&act,NULL)==-1)
    {
        perror("sigpipe");
        exit(EXIT_FAILURE);
    }
    
    // Iniciliazing the set
    FD_ZERO(&current_fd_set);
    FD_SET(STDIN_FILENO,&current_fd_set);

    // Server loop
    while(ok && !ex)
    {   
        // Because select is destrutive
        ready_fd_set = current_fd_set;

        // Only unblocks from this point when select finds events ready for reading 
        if((num_fd = select(FD_SETSIZE,&ready_fd_set,(fd_set*)NULL,(fd_set*)NULL,&time_limit))<0)
        {
            ok=0;
            break;
        }

        // In case of a time Out
        if(num_fd == 0) timeOut=1;

        // Searching for the file descriptor that is selected
        for(int i=0; i<FD_SETSIZE; i++)
        {   
            // Verifies if 'i' file descriptor belong to may set
            if(FD_ISSET(i,&ready_fd_set))
            {   
                if(i==STDIN_FILENO)
                {   
                    // Makes the reading
                    if(fgets(command,100,stdin)==NULL)
                    {
                        ok=0;
                        break;
                    }
                    printf("\n");

                    switch(verify(command))
                    {
                    case 1: //new
                        if(set_new(&tcp_server_fd,&tcp_client_fd,&udp_fd,key,ip,port,5)!=0)
                        {
                            ok = 0;
                            break;
                        }

                        FD_SET(tcp_server_fd,&current_fd_set);
                        FD_SET(udp_fd,&current_fd_set);

                        printf("\tserver created\n");

                        break;
                    case 2: // bentry
                        sscanf(command,"%s %d %s %s\n",dummy,&key,ip,port);
                        if(request_bentry(tcp_client_fd,udp_fd,key,ip,port)!=0)
                        {
                            ok=0;
                            break;
                        }
                        
                        close(tcp_client_fd);
                        tcp_client_fd = setup_tcp_client();

                        break;
                    case 3: // pentry
                        sscanf(command,"%s %d %s %s",dummy,&key,ip,port);

                        if(request_pentry(tcp_client_fd,key,ip,port)!=0)
                        {
                            ok=0;
                            break;
                        }

                        close(tcp_client_fd);
                        tcp_client_fd = setup_tcp_client();

                        break;
                    case 4: // chord
                        sscanf(command,"%s %d %s %s\n",dummy,&key,ip,port);

                        if(set_shortcut(key,ip,port)!=0)
                        {
                            ok=0;
                            break;
                        }

                        printf("\tshortcut created\n");

                        break;
                    case 5: // echord
                        if(remove_shortcut()!=0)
                        {
                            ok=0;
                            break;
                        }

                        printf("\tshortcut deleted\n");

                        break;
                    case 6: // show
                        show_state();
                        break;
                    case 7: // find
                        sscanf(command,"%s %d\n",dummy,&key);
                        if(request_find(tcp_client_fd,udp_fd,key)!=0)
                        {
                            ok=0;
                            break;
                        }
                        
                        close(tcp_client_fd);
                        tcp_client_fd = setup_tcp_client();

                        break;
                    case 8: // leave
                        if(request_leave(tcp_client_fd)!=0)
                        {
                            ok=0;
                            break;
                        }

                        close(tcp_client_fd);
                        tcp_client_fd = setup_tcp_client();

                        break;
                    case 9: // exit
                        printf("Exiting...\n");
                        if(leave_and_exit(tcp_client_fd)!=0)
                        {
                            ok=0;
                            break;
                        }

                        ex=1;

                        break;
                    case 10:
                        print_usage();
                        break;
                    default:
                        printf("Invalid Command.\nSee Command Usage with 'help' or 'h' command\n");
                        break;
                    }

                    printf("\n");                
                }
                else if(i==tcp_server_fd)
                {
                    addrlen=sizeof(addr);
                    
                    // Gets client file descriptor that select told us that was ready
                    if((client_fd=accept(tcp_server_fd,&addr,&addrlen))==-1)
                    {
                        ok=0;
                        break;
                    }

                    // Gets the request
                    if(read_all(client_fd,buffer,128)!=0)
                    {
                        ok=0;
                        break;
                    }

                    printf("[tcp] received: ");
                    printf(buffer);

                    if(tcp_msg_handler(tcp_client_fd,udp_fd,buffer)!=0)
                    {
                        ok=0;
                        break;
                    }

                    close(tcp_client_fd);
                    tcp_client_fd = setup_tcp_client();

                    close(client_fd);

                    printf("\n");
                }
                else if(i==udp_fd || num_fd == 0)
                {   
                    // Reads the received information
                    if((udp_addr=ring_recvfrom(udp_fd,buffer,128,&timeOut))==NULL)
                    {
                        ok=0;
                        break;
                    }
                    
                    if(strstr(buffer,"IGNORE")==NULL) printf("[udp] received: %s\n",buffer);

                    if(udp_msg_handler(tcp_client_fd,udp_fd,(struct sockaddr*) udp_addr,buffer)!=0)
                    {
                        ok=0;
                        break;
                    }
                    
                    memset(buffer,0,MAX_BUFFER_SIZE);

                    free(udp_addr);
                    udp_addr = NULL;
                    close(tcp_client_fd);
                    tcp_client_fd = setup_tcp_client();

                    printf("\n");
                } 
            }
        }
    }

    if(ex || !ok) free_resource();

    FD_CLR(STDIN_FILENO,&current_fd_set);

    if(tcp_server_fd < 0) FD_CLR(tcp_server_fd,&current_fd_set);
    
    if(udp_fd < 0) FD_CLR(udp_fd,&current_fd_set);

    if(tcp_server_fd < 0) close(tcp_client_fd);
    
    if(udp_fd < 0) close(udp_fd);
    
    if(tcp_server_fd < 0) close(tcp_server_fd);

    if(udp_addr!=NULL) free(udp_addr); 

    if(!ok)
    {   
        perror("ERROR");
        exit(EXIT_FAILURE);
    }

    exit(EXIT_SUCCESS);
}